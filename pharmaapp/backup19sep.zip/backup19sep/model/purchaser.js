var config = require('../config/database.js');

var twilio = require('twilio');
var client = twilio(config.accountSid, config.authToken);


// See if we have any phone numbers in the 310 area code...
exports.purchase=function(callback){

  client.incomingPhoneNumbers.list({
      phoneNumber:'+1310*******'
  }, function(listError, listResults) {
      if (listError) {
          console.error('Ruh roh - couldn\'t list numbers because: '+listError.message);
      } else {

        console.log(listResults.incomingPhoneNumbers.length);
          // Check if we have any...
          if (listResults.incomingPhoneNumbers.length != 0) {
              // Buy a US phone number in the 310 area code using callbacks
              client.availablePhoneNumbers('US').local.get({
                  areaCode:'310'
              }, function(searchError, searchResults) {
                    console.log(searchResults.availablePhoneNumbers.length);
                  // handle the case where there are no numbers found
                  if (searchResults.availablePhoneNumbers.length < 1) {
                      console.error('Oh noes! There are no 651 phone numbers!');
                  } else {

                      // Buy the first phone number we found
                      client.incomingPhoneNumbers.create({
                          phoneNumber:searchResults.availablePhoneNumbers[0].phoneNumber,
                        //  voiceUrl:'http://198.61.223.30/voiceReply',
                        //  smsUrl:'http://198.61.223.30/smsReply'
                        voiceUrl:'https://23.253.244.141/voiceReply',
                        smsUrl:'https://23.253.244.141/smsReply'
                      }, function(buyError, number) {
                          if (buyError) {
                            callback(buyError, null);
                              console.error('Buying the number failed. Reason: '+buyError.message);
                          } else {
                              console.log('Number purchased! Phone number is: '+number.phoneNumber);
                              callback(null, number.phoneNumber);
                          }
                      });
                  }

              });
          }
      }
  });
}


//exports.purchase = purchase;
