var connection = require('../config/database');
var sql = require('../config/sql');

exports.createpromo=function(phrase,callback){
  query="INSERT INTO `promocode`(`promocodePhase`,`isActive`,`createdDate`,`deletedDate`) VALUES ('"+phrase+"',1,now(),0000-00-00);SELECT `promoid`,`promocodePhase`,`isActive`,`createdDate` FROM `promocode` WHERE `isDeleted`= 0  ORDER BY `promocode`.`promoid` DESC"
  //SELECT `promoid`,`promocodePhase`,`isActive`,`createdDate`FROM promocode WHERE promoid=(SELECT max(`promoid`) FROM promocode)";
  sql.executeSql(query, function (err, data) {
      if (!err) {
          callback(null, data);
      }
      else {
          callback(err, null);
      }
  });
}
exports.getpromo=function(callback){
  query="SELECT `promoid`,`promocodePhase`,`isActive`,`createdDate` FROM `promocode` WHERE `isDeleted`= 0  ORDER BY `promocode`.`promoid` DESC";
  sql.executeSql(query, function (err, data) {
      if (!err) {

         for (i = 0; i < data.length; i++) {
           var date = data[i].createdDate + " ";
           var train_date = date.split(" ");
           data[i].createdDate = train_date[2] + " " + train_date[1] + " " + train_date[3];
         }
  
          callback(null, data);
      }
      else {
          callback(err, null);
      }
  });
}

exports.deletepromo=function(promoId,callback){

  query='UPDATE `promocode` SET `isActive`=0,`isDeleted`=1 WHERE `promoid`="'+ promoId +'"';

  sql.executeSql(query, function (err, data) {
      if (!err) {
          callback(null, data);
      }
      else {
          callback(err, null);
      }
  });
}
