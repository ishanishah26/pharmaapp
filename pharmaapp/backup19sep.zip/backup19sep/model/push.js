var apn = require('apn');
var message = new apn.notification();
exports.pushNotification = function (alert, msg, deviceToken, callback){
    message.expiry = Math.floor(Date.now() / 1000) + 3600; // Expires 1 hour from now.
    message.badge = 1;
    message.sound = "ping.aiff";
    //message.setAlertText({ "title" : "New Request"});
    message.alert = alert;
    message.payload = msg;
    if (alert == "" || alert == undefined)
        message.alert = "";
    //Cretificate for distribution
    var options = { "gateway": "gateway.push.apple.com", "cert": __dirname + "/Certificates_dist.pem", "key": __dirname + "/Certificates_dist_key.pem", "passphrase": "QApp" };
    //Cretificate for development
    //var options = { "gateway": "gateway.sandbox.push.apple.com", "cert": __dirname + "/Certificatesdev.pem", "key": __dirname + "/CertificatesdevKey.pem", "passphrase": "QApp" };
    var service = new apn.connection(options);

    service.on('connected', function() {
        console.log("Connected");
    });

    service.on('transmitted', function(notification, device) {


        console.log("Notification transmitted to:" + device.token.toString('hex'));
        callback(null, true);
    });

    service.on('transmissionError', function(errCode, notification, device) {
        console.error("Notification caused error: " + errCode + " for device ", device, notification);
        callback(errCode,null);
    });

    service.on('timeout', function () {
        console.log("Connection Timeout");
    });

    service.on('disconnected', function() {
        console.log("Disconnected from APNS");
    });

    service.on('socketError', console.error);

   var deviceId = "cebd1e7ccc173b522fc98ab54b9196828c48056ebf1b77820a1461427d4a7682";
  //  var deviceId = "146ceccfcce645444d2cf1acf0090cc8a6e1a17c";
    var device = new apn.Device(deviceToken);
    service.pushNotification(message, device);
}
