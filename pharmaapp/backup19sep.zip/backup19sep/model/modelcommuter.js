var sql = require('../config/sql');
var settings = require('../config/database');
exports.smsReply=function(tono,callback){
  var query= 'call commuter("' + tono +'")';
  sql.executeSql(query, function (err,data) {
      if (!err) {
	callback(null, data);
	}else{
	callback(err, null);
	}
});
};
	



