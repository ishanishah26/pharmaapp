var gcm = require('node-gcm');
var sql = require('../config/sql');
var connection = require('../config/database');
var gcmSender = new gcm.Sender(connection.gcmSenderKey);
var StripeModel = require('./tblstripe.js');
var encryptor = require('simple-encryptor')(connection.key);
var md5=require('md5');
// connect.connect(function(err){
// if(!err)
// console.log("done connection");
// else
// console.log("error in connection");
// });
//var encryptor = require('simple-encryptor')(connection.key);
//======================================== Change email ===============================

exports.changeEmail = function (userId, email, random, callback) {
    var query = 'CALL change_Email("' + userId + '","' + email + '","' + random + '")';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

// ============================================ verify email ==================================

exports.verifyPassccode = function (userId, passcode, callback) {
    var query = 'UPDATE user SET isEmailVerified = "1" where userId="' + userId + '" and passcode="' + passcode + '"';
    //console.log(query)
    sql.executeSql(query, function (err, data) {
        if (!err) {

            if(data.affectedRows > 0) {
          //callback(err, null);
            query1='SELECT  mobile FROM user WHERE userId="'+ userId +'"';
            sql.executeSql(query1, function (err, data) {
              if (!err) {
                  callback(null, data);
              }
              else {
                  callback(err, null);
              }

            });
          }
            else   callback(null, data);
        }
        else {
            callback(err, null);
        }

    });
}
//======================================== resend Passcode ===============================

exports.resendPasscode = function (userId, random, callback) {
    var query = 'CALL resendOtp_email("' + userId + '","' + random + '")';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//=============================================== edit profile pic ====================================

exports.profilepic = function (userId, image, callback) {
    var query = 'update user set userProfile="' + image + '" where userId="' + userId + '"';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//================================================ Delete Account ======================================

exports.deleteAccount = function (userId, callback) {
    var query = 'CALL delete_Account("' + userId + '")';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== report an issue ==========================================

exports.reportIssue = function (userId, issue, callback) {
    var query = 'insert into reportIssue(issueDetail,userId) values("' + issue + '","' + userId + '") ;' +
                 'SELECT firstName, lastName, email, mobile FROM user WHERE userId = "'+ userId +'" ';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
                callback(err, null);
        }
    });
}

//================================== forgot password verify email from database ===========

exports.forgotPassword = function (email, random, callback) {
    var query = 'update user set forgotRandom ="' + random + '" where email = "' + email + '"';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//===================================== map ==========================================

exports.location = function (userId, Lat, Long, callback) {
    var query = 'SELECT  qId,currentLat,currentLong,roleOfQ, ( 3959 * acos( cos( radians( "' + Lat + '" ) ) * cos( radians( currentLat ) ) * cos( radians( currentLong ) - radians( "' + Long + '" ) ) + sin( radians( "' + Lat + '" ) ) * sin( radians( currentLat ) ) ) ) AS temp '
                                                       + 'FROM qProvider '
                                                       + 'WHERE isQOnline = "1" and userId <> "' + userId + '"'
                                                       + 'having temp < 25';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//================================== verify that link is used or not ======================

exports.forgotPasswordLink = function (email, random, callback) {
    var query = 'update user set forgotRandom = 0 where email = "' + email + '" and forgotRandom = "' + random + '"';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//================================== reset password ======================================

exports.resetPassword = function (email, password, callback) {
    var password1=password;
    var Epassword=md5(password1);
    var query = 'update user set password = "' + Epassword + '" where email = "' + email + '"';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== user Card detail ==========================================

exports.userCard = function (userId, token, cardNumber, callback) {
    //var cardNumber1 = cardNumber;
    //var EcardNumber = encryptor.encrypt(cardNumber1);

    //var token1 = token;
    //var Etoken =encryptor.encrypt(token);

    //var query = 'insert into userCard(userId,cardNumber,cardToken) values("' + userId + '","' + cardNumber + '","' + token + '")';
    var query = 'CALL create_userCard("' + userId + '","' + cardNumber + '","' + token + '")';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            if (data[0][0].stripeCustomerAccount == "" || data[0][0].stripeCustomerAccount == null || data[0][0].stripeCustomerAccount == undefined) {
                StripeModel.createStripeCustomer(userId, token, function (err, data) {
                    if (!err) {
                        callback(null, data);
                    } else {
                        callback(err, null);
                    }
                });
            } else {
                StripeModel.updateStripeCustomer(userId, token, function (err, data) {
                    if (!err) {
                        callback(null, data);
                    } else {
                        callback(err, null);
                    }
                });
            }
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== change email from profile ==========================================

exports.changeProfileEmail = function (userId, random, newEmail, callback) {
    var query = 'CALL changeProfile_Email("' + userId + '","' + newEmail + '","' + random + '")';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== change mobile from profile ==========================================

exports.resendPasscodeEmail = function (userId, random, callback) {
    var query = 'UPDATE user SET Passcode = "' + random + '" WHERE userId = "' + userId + '"; SELECT firstName,changedEmail FROM user WHERE userId = "' + userId + '";';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== update email from profile ==========================================

exports.updateEmail = function (userId, random, callback) {
    var query = 'CALL update_Email("' + userId + '","' + random + '")';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== change mobile from profile ==========================================

exports.changeProfileMobile = function (userId, random, newMobile, callback) {
    var query = 'UPDATE user SET isMobileverified = "0", mobile = "' + newMobile + '", mobilePasscode = "' + random + '" WHERE userId = "' + userId + '"';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== change mobile from profile ==========================================

exports.resendPasscodeMobile = function (userId, random, callback) {
    var query = 'UPDATE user SET mobilePasscode = "' + random + '" WHERE userId = "' + userId + '"; SELECT mobile FROM user WHERE userId = "' + userId + '";';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== Verify mobile for user profile ==========================================

exports.verifyMobilePasscode = function (userId, random, callback) {
    var query = 'UPDATE user SET isMobileverified = 1 WHERE userId = "' + userId + '" and mobilePasscode ="' + random + '";';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== update mobile from profile ==========================================

exports.updateMobile = function (userId, random, callback) {
    var query = 'CALL update_Mobile("' + userId + '","' + random + '")';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== update mobile from profile ==========================================

exports.totalCompletedRequest = function (userId, callback) {
    var query = "SELECT count(*) as TotalRequestCompleted, sum(qRequestAccept.paymentReceivedByQ) as TotalPaymentReceived FROM qRequestAccept join 	qProvider on qRequestAccept.qId = qProvider.qId WHERE qRequestAccept.isConfirmedByQ = 1 and qProvider.userId =  " + userId;
    sql.executeSql(query, function (err, data) {
        if (!err) {
            console.log(data);
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//updateAccountStatus
//========================================== update Account Status ==========================================

exports.updateAccountStatus = function (userId, status, callback) {
    var query = 'UPDATE user SET `isDeleted` = "'+ status +'" WHERE `userId` = "' + userId + '";';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            if (data.affectedRows > 0) {
                newdata = {
                    "message": "User Status Updated",
                    "userId": userId,
                    "isActive": status
                };
            }
            callback(null, newdata);
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== Get Users List ==========================================

exports.getUsersList = function (callback) {
    var query = 'SELECT userId, firstName, lastName, email, mobile, isDeleted FROM user WHERE userType = 0 AND isDeleted <>-1;';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}
