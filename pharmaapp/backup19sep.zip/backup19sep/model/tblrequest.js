var gcm = require('node-gcm');
var sql = require('../config/sql');
var settings = require('../config/database');
var apn = require('./push.js');
var StripeModel = require('./tblstripe.js');
var gcmSender = new gcm.Sender(settings.gcmSenderKey);
var qList = require('../app.js').qList;
var uList = require('../app.js').uList;
var http = require('http');
var fs = require('fs');
var request = require('request');
var par=require('../model/purchaser.js');
// ============================================ Qrequest Any thing else ==================================

exports.qRequestElse = function (userId, curLat, curLong, verb, noun, time, price, isRequireNow, requiredDate, callback) {
  
    StripeModel.prechargeCustomerAccount(userId, function (err, charge) {
        if (err) {
          console.log("err"+err);
            callback(err.raw.message, null);
        } else {
            var query = 'SET @QrequestId = 0; CALL qRequest_anyThingElse("' + userId + '","' + curLat + '","' + curLong + '","' + verb + '","' + noun + '","' + time + '","' + price + '","' + isRequireNow + '","0000-00-00",@QrequestId, "'+ charge.id +'"); SELECT @QrequestId;';
            sql.executeSql(query, function (err, data) {
                if (!err) {
                    var deviceTokenA, deviceTokenI, message, msg, mapURL;
		    	 var requestId;
			 requestId = data[3][0]['@QrequestId'];
			
                        //Saving image on request
                        //code to store MAP image in server
			console.log("settings.mapUrl.format("+curLat +curLong);
                        mapURL = settings.mapUrl.format("", "|" + curLat + "," + curLong);
			
                        var imageName = 'requestMapURLId' + requestId + '.png';
                        download(mapURL, './public/images/' + imageName, function () {
                            console.log('Map image saved on server names: ', imageName);
                            var queryToSaveMapURL = "UPDATE qRequest SET mapURL = '" + imageName + "' WHERE qRequestId = '" + requestId + "'";
                            sql.executeSql(queryToSaveMapURL, function (error, dataMapUrl) {
                                console.log("Map image path saved to database");
                            });
                        });


                    if (data[1].length == 0) {
                        callback(null, data);
                    }
                    else {

                        //START
                        var qIds = "", queryToSetNotifiedQIds = "INSERT INTO requestSentToQ(qRequestId,qId) values ", requestId = data[3][0]['@QrequestId'];


                        for (var i = 0; i < data[1].length; i++) {
                            //START
                            if (i == 0) {
                                qIds += data[1][i].qId;
                                queryToSetNotifiedQIds += "('" + requestId + "', '" + data[1][i].qId + "' )";
                            } else {
                                qIds += "," + data[1][i].qId;
                                queryToSetNotifiedQIds += ",('" + requestId + "', '" + data[1][i].qId + "' )";
                            }
                        }
                        queryToSetNotifiedQIds += ";";
                        // do a POST request
                        // create the JSON object
                        var jsonObject = JSON.stringify({
                            "messageBody": {
                                "key": "Any Thing Else",
                                "Title": "New Request",
                                "Verb": "" + verb,
                                "Noun": "" + noun,
                                "cost": "" + price,
                                "time": "" + time,
                                "Lat": "" + curLat,
                                "Long": "" + curLong,
                                "requestId": "" + requestId
                            },
                            "qIds": qIds
                        });

                        // prepare the header
                        var postheaders = {
                            'Content-Type': 'application/json',
                            'Content-Length': Buffer.byteLength(jsonObject, 'utf8')
                        };

                        // the post options
                        var optionspost = {
                            host: '198.61.223.30',
                            port: 5050,
                            path: '/APIURL',
                            method: 'POST',
                            headers: postheaders
                        };

                        // do the POST call
                        var reqPost = http.request(optionspost, function (res) {
                            console.log("statusCode: ", res.statusCode);

                            if (res.statusCode == 200) {

                                //Update the LastRequestTime in DB
                                var query = "Update qProvider set LastRequestSent = now() where qId in (" + qIds + ")";
                                sql.executeSql(query, function (err, data) {

                                    if (err) {
                                        console.log("Error while updating the LastRequestSent " + err + "  Q---" + qIds);
                                    }
                                    else {
                                        console.log("LastRequestSent Updated for Q succefully " + qIds);
                                    }
                                });

                                //requestSentToQ for resending notifications
                                sql.executeSql(queryToSetNotifiedQIds, function (err, data) {

                                    if (err) {
                                        console.log("Error while updating requestSentToQ, err: " + err + " and Q---" + qIds);
                                    }
                                    else {
                                        console.log("requestSentToQ Updated for Q succefully " + qIds);
                                    }
                                });
                            }

                            // uncomment it for header details
                            //  console.log("headers: ", res.headers);

                            res.on('data', function (d) {
                                console.info('POST result:\n');
                                process.stdout.write(d);
                                console.info('\nPOST completed');
                            });
                        });
                        // write the json data
                        reqPost.write(jsonObject);
                        reqPost.end();
                        reqPost.on('error', function (e) {
                            console.error(e);
                        });

                        //END

                        for (var i = 0; i < data[1].length; i++) {
                            var subquery = 'select deviceToken, deviceType from user where userId = "' + data[1][i].userId + '"';

                            sql.executeSql(subquery, function (err, result) {
                                if (!err && result.length > 0) {
                                    if (result[0].deviceType == 1) {
                                        var message = new gcm.Message({
                                            "data": {
                                                "key1": "Any Thing Else"
                                            },
                                            "notification": {
                                                "Title": "New Request",
                                                "Verb": "'" + verb + "'",
                                                "Noun": "'" + noun + "'",
                                                "cost": "'" + price + "'",
                                                "time": "'" + time + "'",
                                                "Lat": "'" + curLat + "'",
                                                "Long": "'" + curLong + "'",
                                                "requestId": "'" + requestId + "'"
                                            }
                                        });
                                        deviceTokenA = result[0].deviceToken;
                                        gcmSender.send(message, { registrationTokens: [deviceTokenA] }, function (err, response) {
                                            if (err) {
                                                console.error(err);
                                            }
                                            else {
                                                console.log(response);
                                            }
                                        });
                                    }
                                    else {
                                        deviceTokenI = result[0].deviceToken;
                                        var msg = {
                                            "notification": {
                                                "key": "1",
                                                "Title": "New Request",
                                                "Verb": "" + verb,
                                                "Noun": "" + noun,
                                                "cost": "" + price,
                                                "time": "" + time,
                                                "Lat": "" + curLat,
                                                "Long": "" + curLong,
                                                "requestId": "" + requestId
                                            }
                                        };
                                        var alert = "New Request";
                                        apn.pushNotification(alert, msg, deviceTokenI, function (err, response) {
                                            if (err) {
                                                console.log(err);
                                            }
                                            else {
                                                console.log(response);
                                            }
                                        });
                                    }
                                }
                            });
                        }


                        callback(null, data);
                    }
                }
                else {
                    callback(err, null);
                }
            });
        }
    });
}

// ============================================ Qrequest Transport ==================================

exports.qRequestTranport = function (userId, curLat, curLong, verb, noun, time, price, nStops, stops, callback) {
    StripeModel.prechargeCustomerAccount(userId, function (err, charge) {
        if (err) {
            //console.log("err"+err);
            callback(err.raw.message, null);
        } else {
            var requestId;
            //console.log("in Transport method");
            //console.log("stop: ", stops);
            var query = 'SET @QrequestId = 0; CALL qRequest_Tranport("' + userId + '","' + stops[0].lat + '","' + stops[0].long + '","' + verb + '","' + noun + '","' + time + '","' + price + '","' + nStops + '",@QrequestId, "'+ charge.id +'"); SELECT @QrequestId;';
            //console.log(query);
            sql.executeSql(query, function (err, data) {

                if (!err) {
			var requestId;
			requestId = data[3][0]['@QrequestId'];
			
			var mapURL;
		    //Saving image on request
                        //code to store MAP image in server
                        mapURL = settings.mapUrl.format(stopMarkers, "|" + curLat + "," + curLong);
                        var imageName = 'requestMapURLId' + requestId + '.png';
                        download(mapURL, './public/images/' + imageName, function () {
                            console.log('Map image saved on server named: ', imageName);
                            var queryToSaveMapURL = "UPDATE qRequest SET mapURL = '" + imageName + "' WHERE qRequestId = '" + requestId + "'";

                            sql.executeSql(queryToSaveMapURL, function (error, dataMapUrl) {
                                console.log("Map image path saved to database");
                            });
                        });

                    var deviceTokenA, deviceTokenI, stopMarkers = "";
                    
                    for (var i = 0; i < stops.length; i++) {
                        var stopId = i + 1;
                        stopMarkers += "|" + stops[i].lat + "," + stops[i].long;
                        sql.executeSql('insert into stopDetail(stopDetailId,qRequestId,stopLat,stopLong,address) values(' + stopId + ',"' + requestId + '","' + stops[i].lat + '","' + stops[i].long + '","' + stops[i].address + '")', function (err, next) {
                            if (err) {
                                callback(err, null);
                            }
                        });
                    }
                    if (data[1].length == 0) {
                        callback(null, data);
                    }
                    else {
                        //START
                        var qIds = "", queryToSetNotifiedQIds = "INSERT INTO requestSentToQ(qRequestId,qId) values ", mapURL;
                        

                        for (var i = 0; i < data[1].length; i++) {
                            //START
                            if (i == 0) {
                                qIds += data[1][i].qId;
                                queryToSetNotifiedQIds += "('" + requestId + "', '" + data[1][i].qId + "' )";
                            } else {
                                qIds += "," + data[1][i].qId;
                                queryToSetNotifiedQIds += ",('" + requestId + "', '" + data[1][i].qId + "' )";
                            }
                        }
                        queryToSetNotifiedQIds += ";";
                        // do a POST request
                        // create the JSON object
                        var jsonObject = JSON.stringify({
                            "messageBody": {
                                "key": "Transport",
                                "Title": "New Request",
                                "Verb": "" + verb,
                                "Noun": "" + noun,
                                "cost": "" + price,
                                "time": "" + time,
                                "Lat": "" + curLat,
                                "Long": "" + curLong,
                                "requestId": "" + requestId
                            },
                            "qIds": qIds
                        });

                        // prepare the header
                        var postheaders = {
                            'Content-Type': 'application/json',
                            'Content-Length': Buffer.byteLength(jsonObject, 'utf8')
                        };

                        // the post options
                        var optionspost = {
                            host: '198.61.223.30',
                            port: 5050,
                            path: '/APIURL',
                            method: 'POST',
                            headers: postheaders
                        };
                        try {
                            // do the POST call
                            var reqPost = http.request(optionspost, function (res) {

                                if (res.statusCode == 200) {

                                    //Update the LastRequestTime in DB
                                    var query = "Update qProvider set LastRequestSent = now() where qId in (" + qIds + ")";
                                    sql.executeSql(query, function (err, data) {

                                        if (err) {
                                            console.log("Error while updating the LastRequestSent " + err + "  Q---" + qIds);
                                        }
                                        else {
                                            console.log("LastRequestSent Updated for Q succefully " + qIds);
                                        }
                                    });

                                    //requestSentToQ for resending notifications
                                    sql.executeSql(queryToSetNotifiedQIds, function (err, data) {

                                        if (err) {
                                            console.log("Error while updating requestSentToQ, err: " + err + " and Q---" + qIds);
                                        }
                                        else {
                                            console.log("requestSentToQ Updated for Q succefully " + qIds);
                                        }
                                    });
                                }

                                console.log("statusCode: ", res.statusCode);
                                // uncomment it for header details
                                //  console.log("headers: ", res.headers);

                                res.on('data', function (d) {
                                    console.info('POST result:\n');
                                    process.stdout.write(d);
                                    console.info('\nPOST completed');
                                });
                            });
                            // write the json data
                            reqPost.write(jsonObject);
                            reqPost.end();
                            reqPost.on('error', function (e) {
                                console.error(e);
                            });
                        } catch (err) {
                            console.log(err.message);
                        }
                        //END

                        for (var i = 0; i < data[1].length; i++) {
                            var subquery = 'select deviceToken, deviceType from user where userId = "' + data[1][i].userId + '"';
                            sql.executeSql(subquery, function (err, result) {

                                if (!err && result.length > 0) {
                                    if (result[0].deviceType == 1) {
                                        deviceTokenA = result[0].deviceToken;
                                        var message = new gcm.Message({
                                            "data": {
                                                "key1": "Transport"
                                            },
                                            "notification": {
                                                "Title": "New Request",
                                                "Verb": "'" + verb + "'",
                                                "Noun": "'" + noun + "'",
                                                "cost": "'" + price + "'",
                                                "time": "'" + time + "'",
                                                "Lat": "'" + curLat + "'",
                                                "Long": "'" + curLong + "'",
                                                "requestId": "'" + requestId + "'"
                                            }
                                        });
                                        gcmSender.send(message, { registrationTokens: [deviceTokenA] }, function (err, response) {
                                            if (err) {
                                                console.error("gcm err"+err);
                                            }
                                            else {
                                                console.log(response);
                                            }
                                        });
                                    }
                                    else {
                                        deviceTokenI = result[0].deviceToken;
                                        console.log(deviceTokenI);
                                        var msg = {
                                            "notification": {
                                                "key": "1",
                                                "Title": "New Request",
                                                "Verb": "" + verb,
                                                "Noun": "" + noun,
                                                "cost": "" + price,
                                                "time": "" + time,
                                                "Lat": "" + curLat,
                                                "Long": "" + curLong,
                                                "requestId": "" + requestId
                                            }
                                        };
                                        var alert = "New Request";
                                        apn.pushNotification(alert, msg, deviceTokenI, function (err, response) {
                                            if (err) {
                                                console.log(err);
                                            }
                                            else {
                                                console.log(response);
                                            }
                                        });
                                    }
                                }
                            });
                        }

                        callback(null, data);
                    }
                }
                else {
                    callback(err, null);
                }
            });
        }
    })
}

//========================================== request history Id ==========================================

exports.showRequest = function (requestId, callback) {
    var query = 'CALL show_Request("' + requestId + '")';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== request accept ==========================================

exports.requestAccept = function (requsetId, qId, callback) {
    var query = 'CALL request_Accept("' + requsetId + '","' + qId + '")';
    sql.executeSql(query, function (err, data) {
        if (!err) {

       	 if (data[0][0].msg == 'accept now'){
              
               par.purchase(function(err, data){
                 if(!err)
                 {
                   var purchaseno = data;
                   var query1='UPDATE `qRequestAccept` SET `purchasedNumber`="' + purchaseno +'"  WHERE `qRequestId`="'+ requsetId +'" ' ;
                   console.log(query1);
                   sql.executeSql(query1, function (err, data) {
                       if (!err) {
                         console.log("purchased no inserted");
                       }
                       else {
                         console.log(err);
                       }
                     });
                 }
                 else {
                   console.log(err);
                 }
               });
              
              
             }
            var deviceTokenA, deviceTokenI;
            if (data[0][0].msg == 'accept now' && data[1].length > 0) {
                if (data[1][0].deviceType == 1) {
                    var message = new gcm.Message({
                        "data": {
                            "key1": "Request Accepted"
                        },
                        "notification": {
                            "Title": "Request Accepted",
                            "Verb": "'" + data[1][0].requestVerb + "'",
                            "Noun": "'" + data[1][0].requestNoun + "'",
                            "isTransport": "" + data[1][0].isTransport,
                            "requestId": "'" + requsetId + "'",
                            "Message": "Your request accepted"
                        }
                    });
                    deviceTokenA = data[1][0].deviceToken;
                    console.log("in android");
                    console.log(deviceTokenA);
                    gcmSender.send(message, { registrationTokens: [deviceTokenA] }, function (err, response) {
                        if (err) {
                            console.error(err);
                        }
                        else {
                            console.log(response);
                        }
                    });
                }
                else {
                    deviceTokenI = data[1][0].deviceToken;
                    console.log("in accepted token");
                    console.log(deviceTokenI);
                    var msg = {
                        "notification": {
                            "key": "2",
                            "Title": "Request Accepted",
                            "Verb": "" + data[1][0].requestVerb,
                            "Noun": "" + data[1][0].requestNoun,
                            "isTransport": "" + data[1][0].isTransport,
                            "requestId": "" + requsetId,
                            "Message": "Your request accepted"
                        }
                    };
                    var alert = "Request Accepted";
                    apn.pushNotification(alert, msg, deviceTokenI, function (err, response) {
                        if (err) {
                            console.log(err);
                        }
                        else {
                            console.log(response);
                        }
                    });
                }
            }
            callback(null, data);

        }
        else {
            callback(err, null);
        }
    });
}

//========================================== Q request Completed Confiramtion ==========================================


exports.setIsConfirmed = function (qRequestId, userType, callback) {
    var query = 'CALL confirm_Request("' + qRequestId + '")', stopMarkers = "", mapURL = "";
    sql.executeSql(query, function (err, data) {
        if (!err) {
            if (data[0].length > 0) {
                if (data[0][0].deviceType == 1) {

                    var message = new gcm.Message({
                        "data": {
                            "key1": "Request Completed"
                        },
                        "notification": {
                            "Title": "Request Completed",
                            "Verb": "'" + data[0][0].requestVerb + "'",
                            "Noun": "'" + data[0][0].requestNoun + "'",
                            "cost": "'" + data[0][0].amt + "'",
                            "requestId": "'" + qRequestId + "'"
                        }
                    });
                    deviceTokenA = data[0][0].deviceToken;
                    gcmSender.send(message, { registrationTokens: [deviceTokenA] }, function (err, response) {
                        if (err) {
                            console.error(err);
                        }
                        else {
                            console.log(response);
                        }
                    });
                }
                else {
                    deviceTokenI = data[0][0].deviceToken;
                    var msg = {
                        "notification": {
                            "key": "3",
                            "Title": "Request Completed",
                            "Verb": "" + data[0][0].requestVerb,
                            "Noun": "" + data[0][0].requestNoun,
                            "cost": "" + data[0][0].amt,
                            "requestId": "" + qRequestId
                        }
                    };
                    var alert = "Request Completed";
                    apn.pushNotification(alert, msg, deviceTokenI, function (err, response) {
                        if (err) {
                            console.log(err);
                        }
                        else {
                            console.log(response);
                        }
                    });
                }
                //var a = new Date(); // Now
                var a = new Date(), b, d, min, requestFee, total_payment, total_q, total_app;
                data[0][0].distanceFee =0;
                // Deduct the payment
                if (data[0][0].requestVerb == 'Transport' || data[0][0].requestVerb == 'transport') {
                    for(var z = 0; z < data[3].length ; z++){
                        stopMarkers += "|"+data[3][z].stopLat+","+data[3][z].stopLong
                    }
                    b = data[0][0].acceptDate;
                    d = (b - a);
                    min = (d / 60000) - 60;
                    if (min < 0) {
                        min = 0;
                    }
                    total_q = 0;
                    var diff = Math.abs(new Date() - data[0][0].acceptDate);
                    var minutes = Math.floor((diff / 1000) / 60);
                    //requestFee = ((16 + (data[0][0].milesTransported * 0.20) + (min * 0.25)) * 5 / 100);
                    requestFee = (settings.transportBaseRate + (data[0][0].milesTransported * settings.transportDistanceRate) + (min * settings.transportDurationRate));
                    total_q = total_q + (requestFee * 0.8);
                    total_q = total_q + data[0][0].amt;

                    data[0][0].subtotal =(requestFee + data[0][0].amt);
                    data[0][0].subtotalFee = ((requestFee + data[0][0].amt) * 5 / 100);

                    data[0][0].distanceFee = data[0][0].milesTransported * settings.transportDistanceRate;

                    total_payment = (requestFee + data[0][0].amt) + ((requestFee + data[0][0].amt) * 5.0 / 100.0);
                    //  total_q = data[0][0].amt + ((requestFee * 8) / 10);
                    total_app = total_payment - total_q ;
                }
                else {

                    var diff = Math.abs(new Date() - data[0][0].acceptDate);
                    var minutes = Math.floor((diff / 1000) / 60);
                    b = data[0][0].acceptDate;
                    d = (a - b);
                    min = (d / 60000) - 60;
                    if (min < 0) {
                        min = 0;
                    }
                    total_q = 0;
                    //requestFee = ((19 + (min * 0.30)) * 3.6 / 100);
                    requestFee = (settings.anythingelseBaseRate + (min * settings.anythingelseDurationRate));
                    total_q = total_q + (requestFee * 0.8); //15.2
                    total_q = total_q + data[0][0].amt; //15.2

                    data[0][0].subtotal =  (requestFee + data[0][0].amt);
                    data[0][0].subtotalFee = ((requestFee + data[0][0].amt) * (5.0 / 100.0));

                    total_payment = (requestFee + data[0][0].amt) + ((requestFee + data[0][0].amt) * (5.0 / 100.0));
                    //total_q = data[0][0].amt + ((requestFee * 8) / 10);
                    total_app = (total_payment - total_q);

                }

                data[0][0].totalMinutes = min;
                data[0][0].durationFee = min*settings.anythingelseDurationRate;

                data[0][0].userCardName = data[1][0].cardNumber;

                console.log ("passed custom fields");
                mapURL = settings.mapUrl.format(stopMarkers, "|"+data[0][0].currentLat+","+data[0][0].currentLong);

                //code to store MAP image in server
                var imageName = 'requestMapURLId'+ qRequestId +'.png';
                download(mapURL, './public/images/' + imageName, function(){
                    console.log('Map image saved on server named: ',imageName);
                    var queryToSaveMapURL = "UPDATE qRequest SET mapURL = '" + imageName + "' WHERE qRequestId = '" + qRequestId + "'";
                    sql.executeSql(queryToSaveMapURL, function (error, dataMapUrl) {
                	    console.log("Map image path saved to database");
                    });
                });

                var amtToCharge = (Number((total_payment).toFixed(2)) * 100);
                data[0][0].receiptTotalBill = amtToCharge;
                data[0][0].requestFee = requestFee;
                data[0][0].serviceFeeToQ = requestFee * settings.serviceFeeToQ;
                data[0][0].serviceFeeToUser = requestFee * settings.serviceFeeToUser;
                var amtOfFee = (Number((total_app).toFixed(2)) * 100);
                var chargeDetails = {
                    minutes: minutes,
                    requestFee: requestFee,
                    totalPayment: amtToCharge,
                    totalPayableAmountToQ: total_q,
                    applicationFee: amtOfFee
                }
                var stripeCustomerAccount = "";
                if (data[1].length > 0) {
                    stripeCustomerAccount = data[1][0].stripeCustomerAccount;
                }
                if (stripeCustomerAccount == "") {
                    var query = 'CALL reverse_Confirm_Request("' + qRequestId + '")';
                    sql.executeSql(query, function (err, data) {
                        console.log("Reversed changes for: ", qRequestId, " as customer account was not created. customerId: ", data[1][0].stripeCustomerAccount);
                    });
                    console.log ("empty Stripe customer account ");
                    console.log (data);
                    callback(true, false);
                } else {

                    StripeModel.createCharge(amtToCharge, stripeCustomerAccount, amtOfFee, data[0][0].qStripeId, data[0][0].qId, qRequestId, requestFee, function (err, chargedData) {
                        if (!err) {
                            var SendNotificationOfCharge = {
                                "Notify": [
                                    {
                                        "deviceToken": data[0][0].deviceToken,
                                        "deviceType": data[0][0].deviceType
                                    },
                                    {
                                        "deviceToken": data[2][0].qDeviceToken,
                                        "deviceType": data[2][0].qDeviceType
                                    }]
                            };
                            for (var i = 0; i < SendNotificationOfCharge.Notify.length; i++) {
                                if (SendNotificationOfCharge.Notify[i].deviceType == 1) {
                                    var message = new gcm.Message({
                                        "data": {
                                            "key1": "User Charged"
                                        },
                                        "notification": {
                                            "Title": "User charged for request",
                                            "Verb": "'" + data[0][0].requestVerb + "'",
                                            "Noun": "'" + data[0][0].requestNoun + "'",
                                            "cost": "'" + data[0][0].amt + "'",
                                            "requestId": "'" + qRequestId + "'",
                                            "amountCharged": "" + (chargedData.amount / 100)
                                        }
                                    });
                                    deviceTokenA = SendNotificationOfCharge.Notify[i].deviceToken;
                                    gcmSender.send(message, { registrationTokens: [deviceTokenA] }, function (err, response) {
                                        if (err) {
                                            console.error(err);
                                        }
                                        else {
                                            console.log(response);
                                        }
                                    });
                                }
                                else {
                                    deviceTokenI = SendNotificationOfCharge.Notify[i].deviceToken;
                                    var msg = {
                                        "notification": {
                                            "key": "5",
                                            "Title": "Request Completed",
                                            "Verb": "" + data[0][0].requestVerb,
                                            "Noun": "" + data[0][0].requestNoun,
                                            "cost": "" + data[0][0].amt,
                                            "requestId": "" + qRequestId,
                                            "amountCharged": "" + (chargedData.amount / 100)
                                        }
                                    };
                                    var alert = "User Charged";
                                    apn.pushNotification(alert, msg, deviceTokenI, function (err, response) {
                                        if (err) {
                                            console.log(err);
                                        }
                                        else {
                                            console.log(response);
                                        }
                                    });
                                }
                            }
                        } else {
                            //Code if stripe fails to charge user
                            var query = 'CALL reverse_Confirm_Request("' + qRequestId + '")';
                            sql.executeSql(query, function (sqlerr, data) {
                                if(!sqlerr){
                                    console.log("Reversed changes for: ", qRequestId, " as error: ", err);
                                }
                            });
                        }
                    });
                }
            }
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== receipt Upload ==========================================

exports.receiptUpload = function (qRequestId, filePath, billAmount, callback) {
    var query = 'insert into qRequestBillImages(qRequestId,billImage,billAmount) values("' + qRequestId + '","' + filePath + '","' + billAmount + '")';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== Q request total miles Transported  ==========================================

exports.setMilesTransported = function (qRequestId, milesTransported, callback) {
    var query = 'UPDATE qRequestAccept SET milesTransported="' + milesTransported + '" WHERE qRequestId = "' + qRequestId + '"';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}


/*
//========================================== Q receipt total bill ==========================================

exports.setqReceiptBill = function (qRequestId, receiptTotalBill, milesTransported, callback) {
    var query = 'UPDATE qRequestAccept SET receiptTotalBill="' + receiptTotalBill + '",milesTransported="' + milesTransported + '" WHERE qRequestId = "' + qRequestId + '"';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}
*/
//========================================== change status reached at stop ==========================================

exports.changeStatusOfStop = function (qRequestId, Lat, Long, callback) {
    var query = "CALL  reached_AtStop ('" + qRequestId + "'," + Lat + "," + Long + ")";
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== change status reached at stop ==========================================

exports.totalCompletedStop = function (qRequestId, callback) {
    var query = 'select stopDetailId as completedStop from stopDetail WHERE qRequestId = "' + qRequestId + '" and isQReachedAtStop = 1';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== cancel request ==========================================

exports.cancelRequest = function (qRequestId, callback) {
    var query = 'Call cancel_Request("' + qRequestId + '")';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            console.log(err);
            callback(err, null);
        }
    });
}

//========================================== cancel request ==========================================

exports.confirmCancelRequest = function (qRequestId, callback) {

    var query = 'CALL cancelpanelty("' + qRequestId + '")';//, paneltyAmount = settings.servicePaneltyCharge * 100;
    sql.executeSql(query, function (err, data) {
        if (!err) {
                    if (data[1].length > 0) {

                StripeModel.chargeCustomerAccount(500, data[1][0].stripeCustomerAccount, function (err, data) {
                    if(err)

                        console.log("Panelty charge failed for request: ", qRequestId, ", error: ", err);
                });
            }

            if (data[0].length > 0) {

                if (data[0][0].deviceType == 1) {
                    var message = new gcm.Message({
                        "data": {
                            "key1": "Request Cancelled"
                        },
                        "notification": {
                            "Title": "Request Cancelled",
                            "Verb": "'" + data[0][0].requestVerb + "'",
                            "Noun": "'" + data[0][0].requestNoun + "'",
                            "requestId": qRequestId
                        }
                    });
                    deviceTokenA = data[0][0].deviceToken;
                    gcmSender.send(message, { registrationTokens: [deviceTokenA] }, function (err, response) {
                        if (err) {
                            console.error(err);
                        }
                        else {
                            console.log(response);
                        }
                    });
                }
                else {
                    deviceTokenI = data[0][0].deviceToken;
                    var msg = {
                        "notification": {
                            "key": "4",
                            "Title": "Request Cancelled",
                            "Verb": "" + data[0][0].requestVerb,
                            "Noun": "" + data[0][0].requestNoun,
                            "requestId": qRequestId
                        }
                    };
                    var alert = "Request Cancelled";
                    apn.pushNotification(alert, msg, deviceTokenI, function (err, response) {
                        if (err) {
                            console.log(err);
                        }
                        else {
                            console.log(response);
                        }
                    });
                }
            }
            callback(null, data);
        }
        else {
          console.log("confirm cancel err"+err);
            callback(err, null);
        }
    });
}


//declineRequests


//========================================== cancel request ==========================================

exports.declineRequests = function (callback) {
    //var query = 'UPDATE qRequest SET requestStatus=-1 WHERE requestStatus=1';
    var query = 'UPDATE qRequest SET requestStatus=-1 WHERE requestStatus=1 AND TIMESTAMPDIFF(MINUTE, qRequest.createdDate , NOW() ) > 60';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//===============================================   20 second   ========================================================

exports.resendRequest = function (callback) {

    var query = "SELECT * FROM `qRequest` WHERE requeststatus =1 and TIMESTAMPDIFF(MINUTE,createdDate,now()) <60 ";
    sql.executeSql(query, function (err, data) {

        if (!err) {

            for (var i = 0; i < data.length; i++) {

                if (data[i].isTransport == 1) {

                    var query = 'CALL qRequest_Tranport_resend("' + data[i].userId + '","' + data[i].currentLat + '","' + data[i].currentLong + ')';
                    sql.executeSql(query, function (err, dataq) {

                        if (!err) {
                            //START
                            var qIds = "";
                            for (var j = 0; j < dataq.length; j++) {
                                //START
                                if (i == 0) {
                                    qIds += dataq[j].qId;
                                } else {
                                    qIds += "," + dataq[j].qId;
                                }
                            }



                            // do a POST request
                            // create the JSON object
                            var jsonObject = JSON.stringify({
                                "messageBody": {
                                    "key": "Transport",
                                    "Title": "New Request",
                                    "Verb": "" + data[i].requestVerb,
                                    "Noun": "" + data[i].requestNoun,
                                    "cost": "" + data[i].qRequiredPayment,
                                    "time": "" + data[i].qRequiredTime_Hr,
                                    "Lat": "" + data[i].currentLat,
                                    "Long": "" + data[i].currentLong,
                                    "requestId": "" + data[i].qRequestId
                                },
                                "qIds": qIds
                            });

                            // prepare the header
                            var postheaders = {
                                'Content-Type': 'application/json',
                                'Content-Length': Buffer.byteLength(jsonObject, 'utf8')
                            };

                            // the post options
                            var optionspost = {
                                host: '198.61.223.30',
                                port: 5050,
                                path: '/APIURL',
                                method: 'POST',
                                headers: postheaders
                            };
                            try {
                                // do the POST call
                                var reqPost = http.request(optionspost, function (res) {

                                    if (res.statusCode == 200) {

                                        //Update the LastRequestTime in DB
                                        var query = "Update qProvider set LastRequestSent = now() where qId in (" + qIds + ")";
                                        sql.executeSql(query, function (err, data) {

                                            if (err) {
                                                console.log("Error while updating the LastRequestSent " + err + "  Q---" + qIds);
                                            }
                                            else {
                                                console.log("LastRequestSent Updated for Q succefully " + qIds);
                                            }
                                        });
                                    }

                                    console.log("statusCode: ", res.statusCode);
                                    // uncomment it for header details
                                    //  console.log("headers: ", res.headers);

                                    res.on('data', function (d) {
                                        console.info('POST result:\n');
                                        process.stdout.write(d);
                                        console.info('\nPOST completed');

                                    });
                                });
                                // write the json data
                                reqPost.write(jsonObject);
                                reqPost.end();
                                reqPost.on('error', function (e) {
                                    console.error(e);
                                });
                            } catch (err) {
                                console.log(err.message);
                            }
                            //END

                            for (var i = 0; i < data.length; i++) {
                                var subquery = 'select deviceToken, deviceType from user where userId = "' + data[1][i].userId + '"';
                                sql.executeSql(subquery, function (err, result) {
                                    if (result[0].deviceType == 1) {
                                        deviceTokenA = result[0].deviceToken;
                                        var message = new gcm.Message({
                                            "data": {
                                                "key1": "Transport"
                                            },
                                            "notification": {
                                                "Title": "New Request",
                                                "Verb": "'" + verb + "'",
                                                "Noun": "'" + noun + "'",
                                                "cost": "'" + price + "'",
                                                "time": "'" + time + "'",
                                                "Lat": "'" + curLat + "'",
                                                "Long": "'" + curLong + "'",
                                                "requestId": "'" + data[3][0]['@QrequestId'] + "'"
                                            }
                                        });
                                        gcmSender.send(message, { registrationTokens: [deviceTokenA] }, function (err, response) {
                                            if (err) {
                                                console.error(err);
                                            }
                                            else {
                                                console.log(response);
                                            }
                                        });
                                    }
                                    else {
                                        deviceTokenI = result[0].deviceToken;
                                        console.log(deviceTokenI);
                                        var msg = {
                                            "notification": {
                                                "key": "1",
                                                "Title": "New Request",
                                                "Verb": "" + verb,
                                                "Noun": "" + noun,
                                                "cost": "" + price,
                                                "time": "" + time,
                                                "Lat": "" + curLat,
                                                "Long": "" + curLong,
                                                "requestId": "" + data[3][0]['@QrequestId']
                                            }
                                        };
                                        var alert = "New Request";
                                        apn.pushNotification(alert, msg, deviceTokenI, function (err, response) {
                                            if (err) {
                                                console.log(err);
                                            }
                                            else {
                                                console.log(response);
                                            }
                                        });
                                    }
                                });
                            }

                        }
                        else {
                            callback(err, null);
                        }

                    });

                }
                else {

                    var query = 'CALL qRequest_anyThingElse_resend("' + data[i].userId + '","' + data[i].currentLat + '","' + data[i].currentLong + ')';
                    sql.executeSql(query, function (err, dataq) {

                        if (!err) {
                            //START
                            var qIds = "";
                            for (var i = 0; i < dataq[1].length; i++) {
                                //START
                                if (i == 0) {
                                    qIds += dataq[1][i].qId;
                                } else {
                                    qIds += "," + dataq[1][i].qId;
                                }
                            }



                            // do a POST request
                            // create the JSON object
                            var jsonObject = JSON.stringify({
                                "messageBody": {
                                    "key": "Anything Else",
                                    "Title": "New Request",
                                    "Verb": "" + data[i].requestVerb,
                                    "Noun": "" + data[i].requestNoun,
                                    "cost": "" + data[i].qRequiredPayment,
                                    "time": "" + data[i].qRequiredTime_Hr,
                                    "Lat": "" + data[i].currentLat,
                                    "Long": "" + data[i].currentLong,
                                    "requestId": "" + data[i].qRequestId
                                },
                                "qIds": qIds
                            });

                            // prepare the header
                            var postheaders = {
                                'Content-Type': 'application/json',
                                'Content-Length': Buffer.byteLength(jsonObject, 'utf8')
                            };

                            // the post options
                            var optionspost = {
                                host: '198.61.223.30',
                                port: 5050,
                                path: '/APIURL',
                                method: 'POST',
                                headers: postheaders
                            };
                            try {
                                // do the POST call
                                var reqPost = http.request(optionspost, function (res) {

                                    if (res.statusCode == 200) {

                                        //Update the LastRequestTime in DB
                                        var query = "Update qProvider set LastRequestSent = now() where qId in (" + qIds + ")";
                                        sql.executeSql(query, function (err, data) {

                                            if (err) {
                                                console.log("Error while updating the LastRequestSent " + err + "  Q---" + qIds);
                                            }
                                            else {
                                                console.log("LastRequestSent Updated for Q succefully " + qIds);
                                            }
                                        });
                                    }

                                    console.log("statusCode: ", res.statusCode);
                                    // uncomment it for header details
                                    //  console.log("headers: ", res.headers);

                                    res.on('data', function (d) {
                                        console.info('POST result:\n');
                                        process.stdout.write(d);
                                        console.info('\nPOST completed');

                                    });
                                });
                                // write the json data
                                reqPost.write(jsonObject);
                                reqPost.end();
                                reqPost.on('error', function (e) {
                                    console.error(e);
                                });
                            } catch (err) {
                                console.log(err.message);
                            }
                            //END

                            for (var i = 0; i < data.length; i++) {
                                var subquery = 'select deviceToken, deviceType from user where userId = "' + data[1][i].userId + '"';
                                sql.executeSql(subquery, function (err, result) {
                                    if (result[0].deviceType == 1) {
                                        deviceTokenA = result[0].deviceToken;
                                        var message = new gcm.Message({
                                            "data": {
                                                "key1": "Transport"
                                            },
                                            "notification": {
                                                "Title": "New Request",
                                                "Verb": "" + data[i].requestVerb,
                                                "Noun": "" + data[i].requestNoun,
                                                "cost": "" + data[i].qRequiredPayment,
                                                "time": "" + data[i].qRequiredTime_Hr,
                                                "Lat": "" + data[i].currentLat,
                                                "Long": "" + data[i].currentLong,
                                                "requestId": "" + data[i].qRequestId
                                            }
                                        });
                                        gcmSender.send(message, { registrationTokens: [deviceTokenA] }, function (err, response) {
                                            if (err) {
                                                console.error(err);
                                            }
                                            else {
                                                console.log(response);
                                            }
                                        });
                                    }
                                    else {
                                        deviceTokenI = result[0].deviceToken;
                                        console.log(deviceTokenI);
                                        var msg = {
                                            "notification": {
                                                "key": "1",
                                                "Title": "New Request",
                                                "Verb": "" + data[i].requestVerb,
                                                "Noun": "" + data[i].requestNoun,
                                                "cost": "" + data[i].qRequiredPayment,
                                                "time": "" + data[i].qRequiredTime_Hr,
                                                "Lat": "" + data[i].currentLat,
                                                "Long": "" + data[i].currentLong,
                                                "requestId": "" + data[i].qRequestId
                                            }
                                        };
                                        var alert = "New Request";
                                        apn.pushNotification(alert, msg, deviceTokenI, function (err, response) {
                                            if (err) {
                                                console.log(err);
                                            }
                                            else {
                                                console.log(response);
                                            }
                                        });
                                    }
                                });
                            }

                        }
                        else {
                            callback(err, null);
                        }

                    });
                }


            }

        }
        else {
            callback(err, null);
        }

    });

}

//===============================================   20 second   ========================================================

exports.resendRequestToQ = function (callback) {

    var query = "SELECT * FROM `qRequest` WHERE requeststatus =1 and TIMESTAMPDIFF(MINUTE,createdDate,now()) <60 ";
    sql.executeSql(query, function (err, data) {
        if (!err) {
            for (i = 0; i < data.length; i++) {
                if (data[i].isTransport == 1) {
                    //For Transport
                    var transportQuery = "CALL qRequest_Resend_Transport('" + data[i].qRequestId + "')";
                    sql.executeSql(transportQuery, function (err, dataTransport) {
                        if (!err) {
                            if (dataTransport[0].length > 0) {
                                var flag = 0, qIds = "", queryToSetNotifiedQIds = "INSERT INTO requestSentToQ(qRequestId,qId) values ";
                                for (var j = 0; j < dataTransport[0].length; j++) {
                                    if (flag == 0) {
                                        qIds += dataTransport[0][j].qId;
                                        queryToSetNotifiedQIds += "('" + dataTransport[0][j].qRequestId + "', '" + dataTransport[0][j].qId + "' )";
                                        flag = 1;
                                    } else {
                                        qIds += "," + dataTransport[0][j].qId;
                                        queryToSetNotifiedQIds += ",('" + dataTransport[0][j].qRequestId + "', '" + dataTransport[0][j].qId + "' )";
                                    }
                                }
                                queryToSetNotifiedQIds += ";";
                                // do a POST request
                                // create the JSON object
                                var jsonObject = JSON.stringify({
                                    "messageBody": {
                                        "key": "Transport",
                                        "Title": "New Request",
                                        "Verb": "" + dataTransport[0][0].requestVerb,
                                        "Noun": "" + dataTransport[0][0].requestNoun,
                                        "cost": "" + dataTransport[0][0].qRequiredPayment,
                                        "time": "" + dataTransport[0][0].qRequiredTime_Hr,
                                        "Lat": "" + dataTransport[0][0].currentLat,
                                        "Long": "" + dataTransport[0][0].currentLong,
                                        "requestId": "" + dataTransport[0][0].qRequestId
                                    },
                                    "qIds": qIds
                                });

                                // prepare the header
                                var postheaders = {
                                    'Content-Type': 'application/json',
                                    'Content-Length': Buffer.byteLength(jsonObject, 'utf8')
                                };

                                // the post options
                                var optionspost = {
                                    host: '198.61.223.30',
                                    port: 5050,
                                    path: '/APIURL',
                                    method: 'POST',
                                    headers: postheaders
                                };
                                try {
                                    // do the POST call
                                    var reqPost = http.request(optionspost, function (res) {

                                        if (res.statusCode == 200) {

                                            //Update the LastRequestTime in DB
                                            var query = "Update qProvider set LastRequestSent = now() where qId in (" + qIds + ")";
                                            sql.executeSql(query, function (err, data) {

                                                if (err) {
                                                    console.log("Error while updating the LastRequestSent " + err + "  Q---" + qIds);
                                                }
                                                else {
                                                    console.log("LastRequestSent Updated for Q succefully " + qIds);
                                                }
                                            });

                                            //requestSentToQ for resending notifications
                                            sql.executeSql(queryToSetNotifiedQIds, function (err, data) {

                                                if (err) {
                                                    console.log("Error while updating requestSentToQ, err: " + err + " and Q---" + qIds);
                                                }
                                                else {
                                                    console.log("requestSentToQ Updated for Q succefully " + qIds);
                                                }
                                            });
                                        }

                                        console.log("statusCode: ", res.statusCode);
                                        // uncomment it for header details
                                        //  console.log("headers: ", res.headers);

                                        res.on('data', function (d) {
                                            console.info('POST result:\n');
                                            process.stdout.write(d);
                                            console.info('\nPOST completed');

                                        });
                                    });
                                    // write the json data
                                    reqPost.write(jsonObject);
                                    reqPost.end();
                                    reqPost.on('error', function (e) {
                                        console.error(e);
                                    });
                                } catch (err) {
                                    console.log(err.message);
                                }
                                //END

                                /*for (var i = 0; i < data.length; i++) {
                                    var subquery = 'select deviceToken, deviceType from user where userId = "' + data[1][i].userId + '"';
                                    sql.executeSql(subquery, function (err, result) {
                                        if (result[0].deviceType == 1) {
                                            deviceTokenA = result[0].deviceToken;
                                            var message = new gcm.Message({
                                                "data": {
                                                    "key1": "Transport"
                                                },
                                                "notification": {
                                                    "Title": "New Request",
                                                    "Verb": "" + dataTransport[0][0].requestVerb,
                                                    "Noun": "" + dataTransport[0][0].requestNoun,
                                                    "cost": "" + dataTransport[0][0].qRequiredPayment,
                                                    "time": "" + dataTransport[0][0].qRequiredTime_Hr,
                                                    "Lat": "" + dataTransport[0][0].currentLat,
                                                    "Long": "" + dataTransport[0][0].currentLong,
                                                    "requestId": "" + dataTransport[0][0].qRequestId
                                                }
                                            });
                                            gcmSender.send(message, { registrationTokens: [deviceTokenA] }, function (err, response) {
                                                if (err) {
                                                    console.error(err);
                                                }
                                                else {
                                                    console.log(response);
                                                }
                                            });
                                        }
                                        else {
                                            deviceTokenI = result[0].deviceToken;
                                            console.log(deviceTokenI);
                                            var msg = {
                                                "notification": {
                                                    "key": "1",
                                                    "Title": "New Request",
                                                    "Verb": "" + verb,
                                                    "Noun": "" + noun,
                                                    "cost": "" + price,
                                                    "time": "" + time,
                                                    "Lat": "" + curLat,
                                                    "Long": "" + curLong,
                                                    "requestId": "" + data[3][0]['@QrequestId']
                                                }
                                            };
                                            var alert = "New Request";
                                            apn.pushNotification(alert, msg, deviceTokenI, function (err, response) {
                                                if (err) {
                                                    console.log(err);
                                                }
                                                else {
                                                    console.log(response);
                                                }
                                            });
                                        }
                                    });
                                }*/
                            }
                        }
                    })
                    //Finish Transport
                } else {
                    //For Anything Else
                    var anytingelseQuery = "CALL qRequest_Resend_anyThingElse('" + data[i].qRequestId + "')";
                    sql.executeSql(anytingelseQuery, function (err, dataAnyThingElse) {
                        if (!err) {
                            //START
                            if (dataAnyThingElse[0].length > 0) {
                                var flag = 0, qIds = "", queryToSetNotifiedQIds = "INSERT INTO requestSentToQ(qRequestId,qId) values ";
                                for (var j = 0; j < dataAnyThingElse[0].length; j++) {
                                    if (flag == 0) {
                                        qIds += dataAnyThingElse[0][j].qId;
                                        queryToSetNotifiedQIds += "('" + dataAnyThingElse[0][j].qRequestId + "', '" + dataAnyThingElse[0][j].qId + "' )";
                                        flag = 1;
                                    } else {
                                        qIds += "," + dataAnyThingElse[0][j].qId;
                                        queryToSetNotifiedQIds += ",('" + dataAnyThingElse[0][j].qRequestId + "', '" + dataAnyThingElse[0][j].qId + "' )";
                                    }
                                }
                                queryToSetNotifiedQIds += ";";
                                // do a POST request
                                // create the JSON object
                                var jsonObject = JSON.stringify({
                                    "messageBody": {
                                        "key": "Anything Else",
                                        "Title": "New Request",
                                        "Verb": "" + dataAnyThingElse[0][0].requestVerb,
                                        "Noun": "" + dataAnyThingElse[0][0].requestNoun,
                                        "cost": "" + dataAnyThingElse[0][0].qRequiredPayment,
                                        "time": "" + dataAnyThingElse[0][0].qRequiredTime_Hr,
                                        "Lat": "" + dataAnyThingElse[0][0].currentLat,
                                        "Long": "" + dataAnyThingElse[0][0].currentLong,
                                        "requestId": "" + dataAnyThingElse[0][0].qRequestId
                                    },
                                    "qIds": qIds
                                });

                                // prepare the header
                                var postheaders = {
                                    'Content-Type': 'application/json',
                                    'Content-Length': Buffer.byteLength(jsonObject, 'utf8')
                                };

                                // the post options
                                var optionspost = {
                                    host: '198.61.223.30',
                                    port: 5050,
                                    path: '/APIURL',
                                    method: 'POST',
                                    headers: postheaders
                                };
                                try {
                                    // do the POST call
                                    var reqPost = http.request(optionspost, function (res) {

                                        if (res.statusCode == 200) {

                                            //Update the LastRequestTime in DB
                                            var query = "Update qProvider set LastRequestSent = now() where qId in (" + qIds + ")";
                                            sql.executeSql(query, function (err, data) {

                                                if (err) {
                                                    console.log("Error while updating the LastRequestSent " + err + "  Q---" + qIds);
                                                }
                                                else {
                                                    console.log("LastRequestSent Updated for Q succefully " + qIds);
                                                }
                                            });

                                            //requestSentToQ for resending notifications
                                            sql.executeSql(queryToSetNotifiedQIds, function (err, data) {

                                                if (err) {
                                                    console.log("Error while updating requestSentToQ, err: " + err + " and Q---" + qIds);
                                                }
                                                else {
                                                    console.log("requestSentToQ Updated for Q succefully " + qIds);
                                                }
                                            });
                                        }

                                        console.log("statusCode: ", res.statusCode);
                                        // uncomment it for header details
                                        //  console.log("headers: ", res.headers);

                                        res.on('data', function (d) {
                                            console.info('POST result:\n');
                                            process.stdout.write(d);
                                            console.info('\nPOST completed');

                                        });
                                    });
                                    // write the json data
                                    reqPost.write(jsonObject);
                                    reqPost.end();
                                    reqPost.on('error', function (e) {
                                        console.error(e);
                                    });
                                } catch (err) {
                                    console.log(err.message);
                                }
                                //END

                                /*for (var i = 0; i < data.length; i++) {
                                    var subquery = 'select deviceToken, deviceType from user where userId = "' + data[1][i].userId + '"';
                                    sql.executeSql(subquery, function (err, result) {
                                        if (result[0].deviceType == 1) {
                                            deviceTokenA = result[0].deviceToken;
                                            var message = new gcm.Message({
                                                "data": {
                                                    "key1": "Transport"
                                                },
                                                "notification": {
                                                    "Title": "New Request",
                                                    "Verb": "" + data[i].requestVerb,
                                                    "Noun": "" + data[i].requestNoun,
                                                    "cost": "" + data[i].qRequiredPayment,
                                                    "time": "" + data[i].qRequiredTime_Hr,
                                                    "Lat": "" + data[i].currentLat,
                                                    "Long": "" + data[i].currentLong,
                                                    "requestId": "" + data[i].qRequestId
                                                }
                                            });
                                            gcmSender.send(message, { registrationTokens: [deviceTokenA] }, function (err, response) {
                                                if (err) {
                                                    console.error(err);
                                                }
                                                else {
                                                    console.log(response);
                                                }
                                            });
                                        }
                                        else {
                                            deviceTokenI = result[0].deviceToken;
                                            console.log(deviceTokenI);
                                            var msg = {
                                                "notification": {
                                                    "key": "1",
                                                    "Title": "New Request",
                                                    "Verb": "" + data[i].requestVerb,
                                                    "Noun": "" + data[i].requestNoun,
                                                    "cost": "" + data[i].qRequiredPayment,
                                                    "time": "" + data[i].qRequiredTime_Hr,
                                                    "Lat": "" + data[i].currentLat,
                                                    "Long": "" + data[i].currentLong,
                                                    "requestId": "" + data[i].qRequestId
                                                }
                                            };
                                            var alert = "New Request";
                                            apn.pushNotification(alert, msg, deviceTokenI, function (err, response) {
                                                if (err) {
                                                    console.log(err);
                                                }
                                                else {
                                                    console.log(response);
                                                }
                                            });
                                        }
                                    });
                                }*/

                            }



                        }
                    });

                    //Finish  Anything Else
                }
            }
            callback(null, data);
        }
    });
}

var download = function (uri, filename, callback) {
    request.head(uri, function (err, res, body) {
        console.log('content-type:', res.headers['content-type']);
        console.log('content-length:', res.headers['content-length']);
        request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
    });
};

