var apn = require('apn');
var connection = require('../config/database');
var message = new apn.notification();

exports.pushNotification = function(alert, msg,deviceToken,callback){

    message.expiry = Math.floor(Date.now() / 1000) + 3600; // Expires 1 hour from now.
    message.badge = 1;
    message.sound = "ping.aiff";
    message.setAlertText({ "title" : alert});
    message.payload = msg;

    //var options = { "gateway": "gateway.sandbox.push.apple.com", "cert": __dirname + "/Certificatesdev.pem", "key": __dirname + "/CertificatesdevKey.pem", "passphrase:": "QApp" };
    var options = { "gateway": "gateway.sandbox.push.apple.com", "cert": __dirname + "/Certificates_dist.pem", "key": __dirname + "/Certificates_dist_key.pem", "passphrase:": "QApp" };
  //  var options = { connection.gcmSenderKey }
    var service = new apn.connection(options);

    service.on('connected', function() {
        console.log("Connected");
    });

    service.on('transmitted', function(notification, device) {
        console.log("Notification transmitted to:" + deviceToken);
        callback(null, true)
    });

    service.on('transmissionError', function(errCode, notification, device) {
        console.error("Notification caused error: " + errCode + " for device ", device, notification);
        callback(errCode, null)
    });

    service.on('timeout', function () {
        console.log("Connection Timeout");
    });

    service.on('disconnected', function() {
        console.log("Disconnected from APNS");
    });

    service.on('socketError', console.error);

    var deviceId = "0dce3cebdd08f164db0608db6a8c993c45e956d49ef36e91bd805d2a863f9a86";
    var device = new apn.Device(deviceToken);
    //var device = new apn.Device(deviceId);
    service.pushNotification(message, device);
}
