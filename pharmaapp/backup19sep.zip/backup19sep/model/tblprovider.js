var gcm = require('node-gcm');
var http = require('http');
var sql = require('../config/sql');
var connection = require('../config/database');
var gcmSender = new gcm.Sender(connection.gcmSenderKey);
var tblStripes = require('./tblstripe.js');
//var key = 'Qappkimberlyrealsecretkeyrandom';
var encryptor = require('simple-encryptor')(connection.key);


// ============================================ Qprovider ==============================================
exports.qProviderRequest = function (userId, curLat, curLong, fname, lname, email, zipCode, mobile, address, city, state, callback) {
    var address1=address;
    var Eaddress=encryptor.encrypt(address1);

    var query = 'CALL insert_qProvider("' + userId + '","' + curLat + '","' + curLong + '","' + fname + '","' + lname + '","' + email + '","' + zipCode + '","' + mobile + '","' + Eaddress + '","' + city + '","' + state + '")';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
          console.log(err);
            callback(err, null);
        }
    });
}

//======================================== Qprovide step 3 =======================================

exports.qProviderRequestThird = function (userId, lFname, lMname, lLname, securityNum, dob, dlNum, state, dlExpiration, hsInfo, clgInfo, yearoProfExp, yearoProfAssiExp, qRole, callback) {
    var Sns1=securityNum;
    var Sns=encryptor.encrypt(Sns1);
    var Dno1=dlNum;
    var Dno=encryptor.encrypt(Dno1);

    var name;
    if (lMname == "") {
        name = lFname + " " + lLname;
    } else {
        name = lFname + " " + lMname + " " + lLname;
    }
    var query = 'UPDATE qProvider SET nameOnDL="' + name + '", socialSecurityNo = "' + Sns + '", dateOfBirth = "' + dob + '",dlNo = "' + Dno + '",dlState = "' + state + '",dateOfDlExpiration = "' + dlExpiration + '",hsInfo = "' + hsInfo + '",collegeInfo = "' + clgInfo + '",totalYearOfProfExp = "' + yearoProfExp + '",personalAssistantExp = "' + yearoProfAssiExp + '",roleOfQ = "' + qRole + '",isStateDisclouserAcknowledged = "1",isBackgroundCheckAuthorized = "1",registrationDate = now(),registrationStepCompleted = "7" WHERE userId = "' + userId + '"';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

// ============================================ verify mobile number ==================================

exports.verifyMobile = function (userId, passcode, callback) {
    var query = 'UPDATE qProvider SET isMobileVerified = "1", registrationStepCompleted = "2" where userId="' + userId + '" and mobileVerificationCode ="' + passcode + '"';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//======================================== Change mobile ===============================

exports.changeMobile = function (userId, mobile, random, callback) {
    var query = 'UPDATE qProvider SET mobile="' + mobile + '", mobileVerificationCode="' + random + '" WHERE userId = "' + userId + '"';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//======================================== Change resended otp ===============================

exports.changeOtp = function (userId, random, callback) {
    var query = 'CALL resendOtp_mobile("' + userId + '","' + random + '")';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//======================================== qProvider activate =============================

exports.qProviderActive = function (userId, curLat, curLong, callback) {
    var query = 'UPDATE qProvider SET isQOnline="1", currentLat = "' + curLat + '", currentLong = "' + curLong + '"WHERE isQVerified="1" AND userId="' + userId + '"';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}


exports.checkQBankAccount = function (qId, callback) {

    var query = "Select * from qProvider where qStripeBankId is not null and qStripeBankId <> '' and userId = '" + qId + "'";
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });

}


//=================================== qProvider offline ===================================

exports.qProviderDeactive = function (userId, callback) {
    var query = 'UPDATE qProvider SET isQOnline="0" WHERE userId="' + userId + '"; SELECT qId FROM qProvider WHERE userId="'+ userId +'"';
    sql.executeSql(query, function (err, data) {
        if (!err) {
                //START
                // do a POST request
                // create the JSON object
                var jsonObject = JSON.stringify({
                    "qId": data[1][0].qId
                });
                // prepare the header
                var postheaders = {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(jsonObject, 'utf8')
                };
                // the post options
                var optionspost = {
                    host: '198.61.223.30',
                    port: 5050,
                    path: '/qDisconnectFromSocket',
                    method: 'POST',
                    headers: postheaders
                };
                try {
                    // do the POST call
                    var reqPost = http.request(optionspost, function (res) {

                        if (res.statusCode == 200) {
                            console.log("Q disconnected from socket server qId: ", data[1][0].qId);
                        }

                        console.log("statusCode: ", res.statusCode);
                        // uncomment it for header details
                        //  console.log("headers: ", res.headers);

                        res.on('data', function (d) {
                            console.info('POST result:\n');
                            process.stdout.write(d);
                            console.info('\nPOST completed');
                        });
                    });
                    // write the json data
                    reqPost.write(jsonObject);
                    reqPost.end();
                    reqPost.on('error', function (e) {
                        console.error(e);
                    });
                } catch (err) {
                    console.log(err.message);
                }
                //END
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}
//========================================== Q provider average rating ======================

exports.qProviderAverageRating = function (qId, callback) {
    var query = 'CALL qAverageRating("' + qId + '")';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//======================================== qProvider activate =============================

exports.updateLocationOfQ = function (qId, curLat, curLong, callback) {
    var query = 'update qProvider set currentLat = "' + curLat + '", currentLong = "' + curLong + '"where userId="' + qId + '"';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//======================================== state ==========================================

exports.getstates = function (callback) {
    var query = 'SELECT state_id, state_name FROM state ORDER BY state_name ASC ';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);

        }
        else {
            callback(err, null);
        }
    });
}

//======================================== state ==========================================

exports.getSatusOfQ = function (userId, callback) {
    var query = 'select isQOnline from qProvider where userId = "' + userId + '"';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}


//======================================== qlist ==========================================

exports.qlist = function (callback) {
    var query = "SELECT q.qId, q.firstName,q.lastName, q.roleOfQ, q.email, q.isQVerified, q.qStripeId, q.qStripeBankTokenId, q.qStripeBankId, q.address, q.city, q.state, q.mobile, AVG(qreqa.speedRating+ qreqa.qualityRating)/2 AS averageRating, COUNT(qreqa.isReviewed) as isReviewed "
        + " FROM qRequestAccept AS qreqa "
        + " RIGHT OUTER JOIN qProvider AS q ON q.qId= qreqa.qId AND qreqa.isReviewed=1 WHERE q.isBackgroundCheckAuthorized=1 AND q.isDeleted=0 "
        + " group by q.qId;";
    sql.executeSql(query, function (err, data) {
        if (!err) {
            if (data.length > 0) {
                for (i = 0; i < data.length; i++) {
                    if (data[i].isReviewed == 0) {
                        data[i].averageRating = "A";
                    }
                    if (data[i].averageRating < 0.5) {
                        data[i].averageRating = "F";
                    }
                    else if (data[i].averageRating >= 0.5 && data[i].averageRating < 1.5) {
                        data[i].averageRating = "D";
                    }
                    else if (data[i].averageRating >= 1.5 && data[i].averageRating < 2.5) {
                        data[i].averageRating = "C";
                    }
                    else if (data[i].averageRating >= 2.5 && data[i].averageRating < 3.5) {
                        data[i].averageRating = "B";
                    }
                    else if (data[i].averageRating >= 3.5) {
                        data[i].averageRating = "A";
                    }
                }
                callback(null, data);
            }
            else {
                callback(err, data);
            }
        }
    });
};


//======================================== Update Q verification ==========================================

exports.updateStatus = function (qId, status, ipAddr, callback) {
    var q = "UPDATE qProvider SET isQVerified='" + status + "' WHERE qId='" + qId + "'";

    sql.executeSql(q, function (err, data) {
        if (!err) {
            if (data.affectedRows > 0) {
                data.message = "Q Status Updated";
                newdata = {
                    "message": "Q Status Updated",
                    "qId": qId,
                    "isActive": status
                };

                if (status == 1) {
                    var q = "SELECT * from qProvider WHERE qId='" + qId + "'";

                    sql.executeSql(q, function (err, data) {

                        if (!err) {
                            if (data.length > 0) {

                                if (data[0].qStripeId == '' || data[0].qStripeId == undefined) {
                                  var Dssn=encryptor.decrypt( data[0].socialSecurityNo);
                                    var accountDetails = {
                                        "managed": true,
                                        "country": "US",
                                        "email": data[0].email,
                                        "support_phone": data[0].mobile,
                                        "tos_acceptance": {
                                            "date": Math.floor(Date.now() / 1000),
                                            "ip": ipAddr
                                        },
                                        "legal_entity": {
                                            "address": {
                                                "city": data[0].city,
                                                "country": "US",
                                                "line1": data[0].address,
                                                "postal_code": data[0].zipCode,
                                                "state": data[0].state
                                            },
                                            "dob": {
                                                "day": data[0].dateOfBirth.getDate(),
                                                "month": data[0].dateOfBirth.getMonth() + 1,
                                                "year": data[0].dateOfBirth.getFullYear(),
                                            },
                                            "first_name": data[0].firstName,
                                            "last_name": data[0].lastName,
                                            "type": "individual",
                                            "ssn_last_4":Dssn ,
                                        }
                                    };

                                    tblStripes.createStripeAccount(qId, accountDetails, function (err, data) {

                                        if (err) {

                                            var q = "UPDATE qProvider SET isQVerified='" + 0 + "' WHERE qId='" + qId + "'";

                                            sql.executeSql(q, function (err1, data) {
                                                callback(err, data);

                                            });


                                        }
                                        else {
                                            callback(null, data);

                                        }

                                    });

                                } else {
                                    callback(null, newdata);
                                }
                            }
                        }
                        else {
                            callback(err, data);

                        }

                    });
                } else {
                    callback(null, newdata);
                }

            }
            else {
                callback(err, data);

            }
        }
        else {
            callback(err, data);

        }
    });
};

//======================================== check if Q has stripe account ==========================================
exports.checkQStripeAccount = function (qId, callback) {
    var q = 'SELECT qStripeId FROM qProvider WHERE qStripeId!="" AND qId="' + qId + '"';
    sql.executeSql(q, function (err, data) {
        if (!err) {
            if (data.length > 0) {
                callback(null, data);
            }
            else {
                callback(err, data);
            }
        } else
            callback(err, data);
    });
};


//======================================== Q details by Id ==========================================

exports.qdetailsbyid = function (qId, callback) {
    var query = "SELECT * FROM qProvider WHERE qId='" + qId + "'";
    sql.executeSql(query, function (err, data) {
        if (!err) {
            if (data.length > 0) {
                //console.log(data);
                 data[0].dlNo= encryptor.decrypt(data[0].dlNo);
                 data[0].socialSecurityNo=encryptor.decrypt(data[0].socialSecurityNo);
                 data[0].address=encryptor.decrypt(data[0].address);


                callback(null, data);
            }
            else {
                callback(err, data);
            }
        }
    });
};

//isQProviderVerified
//==========================Qprovider online map===============================



exports.QProvider=function(callback){
    var query = "SELECT firstName,lastName,currentLat,currentLong FROM qProvider WHERE isQVerified = 1 AND isQOnline = 1; ";
    sql.executeSql(query, function (err, data) {
        if (!err) {
            if (data.length > 0) {
                callback(null, data);
            }
        }
    });
}




//======================================== check if Q has stripe account ==========================================
exports.isQProviderVerified = function (userId, callback) {
    var q = 'SELECT isQVerified FROM qProvider WHERE userId IN (SELECT userId FROM user WHERE userId="' + userId + '")';
    sql.executeSql(q, function (err, data) {
        if (!err) {
            if (data.length > 0) {
                callback(null, data);
            }
            else {
                callback(err, data);
            }
        } else
            callback(err, data);
    });
};

//======================================== Update Q service ==========================================
exports.updateService = function (qId, service, callback) {
    var q = 'UPDATE qProvider SET roleOfQ = "' + service + '" WHERE qId = "' + qId + '" ';
    sql.executeSql(q, function (err, data) {
        if (!err) {
            callback(null, data);
        } else
            callback(err, data);
    });
};


//======================================== Q details by userId ==========================================

exports.qdetailsbyuserid = function (userId, callback) {
    var query = "SELECT * FROM qProvider WHERE userId='" + userId + "'";
    sql.executeSql(query, function (err, data) {
        if (!err) {
            if (data.length > 0) {
                callback(null, data);
            }
            else {
                callback(err, data);
            }
        }
    });
};

//======================================== Q details and review by qRequestId ==========================================

exports.qdetailsandreviewbyid = function (qRequestId, callback) {
    var query = "SELECT q.firstName,q.lastName, q.roleOfQ, q.email, q.address, q.city, q.state, q.mobile, (AVG(speedRating+qualityRating)+4)/3 AS averageRating  "
        + " FROM qRequestAccept AS qreqa "
        + " INNER JOIN qProvider AS q ON q.qId= qreqa.qId AND q.qId IN (SELECT qId from qRequestAccept where qRequestId = '" + qRequestId + "') AND qreqa.isReviewed=1";

    sql.executeSql(query, function (err, data) {
        if (!err) {
            if (data.length > 0) {
                callback(null, data);
            }
            else {
                callback(err, data);
            }
        }
    });
};

//======================================== delete Q ==========================================

exports.deleteQ = function (qId, callback) {
    var query = "UPDATE qProvider SET isDeleted=1 WHERE qId= '" + qId + "' ";
    sql.executeSql(query, function (err, data) {
        if (!err) {
            if (data.length > 0) {
                callback(null, data);
            }
            else {
                callback(err, data);
            }
        }
    });
};

//======================================== Update Q ==========================================

exports.UpdateQ = function (qId, firstName, lastName, email, address, city,
                            state, zipCode, mobile, nameOnDL, socialSecurityNo,
                            dateOfBirth, dlNo, dlState, dateOfDlExpiration, totalYearOfProfExp,
                            personalAssistantExp, roleOfQ, isQVerified, isQOnline, callback) {
     var address1=address;
     var Eaddress=encryptor.encrypt(address1);
     var ssn=socialSecurityNo;
     var Ssn=encryptor.encrypt(ssn);
     var dlno=dlNo;
     var Dlno=encryptor.encrypt(dlno);
    var query = "UPDATE qProvider SET firstName='" + firstName + "',lastName='" + lastName + "',email='" + email + "', "
                +" address='" + Eaddress + "',city='" + city + "',state='" + state + "',zipCode='" + zipCode + "',mobile='" + mobile + "', "
                +" nameOnDL='" + nameOnDL + "',socialSecurityNo='" + Ssn + "',dateOfBirth='" + dateOfBirth + "', "
                +" dlNo='" + Dlno + "',dlState='" + dlState + "',dateOfDlExpiration='" + dateOfDlExpiration + "', "
                +" totalYearOfProfExp='" + totalYearOfProfExp + "',personalAssistantExp='" + personalAssistantExp + "', "
                +" roleOfQ='" + roleOfQ + "',isQVerified='" + isQVerified + "',isQOnline='" + isQOnline + "' WHERE qId= '" + qId + "' ";
                console.log(query);
    sql.executeSql(query, function (err, data) {
        if (!err) {
            if (data.affectedRows > 0) {
                callback(null, data);
            }
            else {
                callback(err, null);
            }
        }
    });
};







//======================================== qProvider Update Route =============================

exports.routeMapOfQ = function (qId, curLat, curLong, callback) {


var query = 'INSERT INTO routeMap (qRequestId, currentLat, currentLong) VALUES ("'+qId+'","'+curLat+'","'+curLong+'");';


    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}
