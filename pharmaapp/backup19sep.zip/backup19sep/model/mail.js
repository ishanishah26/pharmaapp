//=========================================== configration =====================================
var settings = require('../config/database');
var nodemailer = require('nodemailer');
//var emailtemplate = require('./emailTemplate');
var emailtemplate = require('./welcomemail.js');
var forgotPasswordEmail = require('./forgotPasswordTemplate');
var completeRequestTemplate = require('./completeRequestTemplate');
var reportIssueTemplate = require('./reportIssueTemplate');
var QregisteredEmail = require('./QregisteredEmail');
var QRatingDroppedEmail = require('./QRatingDroppedEmail');
var receiptUserSolveTemplate = require('./receiptUserSolveTemplate');
var receiptUserErrandTemplate = require('./receiptUserErrandTemplate');
var transReceipts = nodemailer.createTransport(settings.smtpConfigReceipts);
var transVerification = nodemailer.createTransport(settings.smtpConfigVerification);
var moment = require('moment');
var path = require('path');
var connection = require('../config/database');
var sql = require('../config/sql');


//================================================================== otp send =================================




exports.sendEmail = function (email, name, callback) {
    var date = moment().format('MMMM Do YYYY');
    transVerification.sendMail({
        to : email,
        from : "info@theqnowapp.com",
        subject : "Welcome to Q Now!",
        replyTo : "info@theqnowapp.com",
        html: emailtemplate.emailVerification.format(date) // html body
    },
       function (err, data) {
        if (err) {
            callback(err, null);
        }
        else {
            callback(null, data);
        }
    });
}

//=============================================================== forgot password mail ================================

exports.sendEmailForgot = function (email, random, callback) {

    var date = moment().format('MMMM Do YYYY');


    transVerification.sendMail({
        to : email,
        from : "info@theqnowapp.com",
        subject : "Recover Your password",
        replyTo : "info@theqnowapp.com",
        html: forgotPasswordEmail.emailVerification.format("", random, date) // html body
    },
              function (err, data) {
        if (err) {
            callback(err, null);
        }
        else {
            callback(null, data);
        }
    });
}

//=============================================================== complete request ================================

exports.sendEmailComplete = function (email, name, verb, noun, fname, lname, payment, heading, image, transportDetails,
   requestFee, serviceFeeToQ, serviceFeeToUser, totalMinutes, distanceFee, durationFee, reimbursementAmt, subtotal, subtotalFee,
    isTransport, qProfile, userCardName, callback) {

    var path = settings.path
    var emailObj;
    var profilePic;


      if(reimbursementAmt == null){
        reimbursementAmt = 0;
      }


      if(isTransport == 1){
          emailObj = receiptUserErrandTemplate;
      }
      else{
          emailObj = receiptUserSolveTemplate;
      }

      if (qProfile == null || qProfile == "" ) {
         profilePic = "user-profile.png";
      }

      profilePic = path.concat(qProfile);

      var date = moment().format('MMMM Do YYYY');

      subtotalFee = parseFloat(subtotalFee).toFixed(2);
      subtotal = parseFloat(subtotal).toFixed(2);
      var grandTotal = parseFloat(subtotalFee) + parseFloat(subtotal);
      grandTotal =  parseFloat(grandTotal).toFixed(2);

      lname = lname.substring(0,1);

    transReceipts.sendMail({
        to : email,
        from : "receipts@theqnowapp.com",
        subject : "Q Now Receipt",
        replyTo : "info@theqnowapp.com",
        html: emailObj.emailTemplate.format(name, verb, noun, fname, lname, grandTotal, heading, image, transportDetails, date, subtotalFee,
          totalMinutes, parseFloat(distanceFee).toFixed(2), parseFloat(durationFee).toFixed(2), parseFloat(reimbursementAmt).toFixed(2) , subtotal,
           parseFloat(settings.anythingelseBaseRate).toFixed(2), parseFloat(settings.transportBaseRate).toFixed(2), profilePic, userCardName ) // html body
    },
              function (err, data) {
        if (err) {
            callback(err, null);
        }
        else {
            callback(null, data);
        }
    });
}

//================================================= send message for Qprovider registration ==============================

exports.twilioSendMsg = function (toPhonenumber, msg, callback) {

    var client = require('twilio')(settings.TwilioAccountId, settings.TwilioAuthToken);
    //Add +1 to number for sending sms in USA
    client.messages.create({
        to: "+1" + toPhonenumber,
        from: settings.TwilioNumber,
        body: msg,
    }, function (err, message) {
        if (err) {
            console.log(err);
            callback(err, null);
        } else {
            callback(null, message);
        }
    });
};

//================================================= send message user to Qprovider ==============================

exports.twilioSendMsgForUser1 = function (toPhonenumber, fromPhonenumber, msg, callback) {

    var client = require('twilio')(settings.TwilioAccountId, settings.TwilioAuthToken);
    //Add +1 to number for sending sms in USA
    client.messages.create({
        to: "+1" + toPhonenumber,
        from: fromPhonenumber,
        body: msg,
    }, function (err, message) {
        if (err) {
            console.log(err);
            callback(err, null);
        } else {
            callback(null, message);
        }
    });
};
exports.twilioSendMsgForUser = function (toPhonenumber, fromPhonenumber, msg, requestid,callback) {

    var client = require('twilio')(settings.TwilioAccountId, settings.TwilioAuthToken);
    var purchasedno;
    query= 'SELECT  `purchasedNumber` FROM `qRequestAccept` WHERE `qRequestId`="'+requestid +'"';
    sql.executeSql(query, function (err, data) {
        if (!err) {
           if(data[0].purchasedNumber != null || data[0].purchasedNumber != undefined ){
            purchasedno = data[0].purchasedNumber;
		console.log(purchasedno);
            //Add +1 to number for sending sms in USA
            client.messages.create({
                to: "+1" + toPhonenumber,
                from: purchasedno,
                body: msg,
            }, function (err, message) {
                if (err) {
                    console.log(err);
                    callback(err, null);
                } else {
                    callback(null, message);
                }
            });
          }
        }
        else {
              callback(err, null);
            console.log(err);
        }
     });

};
//=============================================================== forgot password mail ================================

exports.sendReportEmail = function (username, issue, email, callback) {
    transVerification.sendMail({
        to : "info@theqnowapp.com",
        from : "info@theqnowapp.com",
        subject : "New Issue Reported",
        replyTo : "info@theqnowapp.com",
        html: reportIssueTemplate.emailReport.format(username, issue, email) // html body
    },
              function (err, data) {
        if (err) {
            callback(err, null);
        }
        else {
            callback(null, data);
        }
    });
}

exports.sendQregistrationComplete = function (Qname, Qrole, email, address, city, state, mobile, callback) {
    transVerification.sendMail({
        to : "hr@theqnowapp.com",
        from : "info@theqnowapp.com",
        subject : "New Q Registered",
        replyTo : "info@theqnowapp.com",
        html: QregisteredEmail.emailHR.format(Qname, Qrole, email, mobile, address, city, state) // html body
    },
              function (err, data) {
        if (err) {
            callback(err, null);
        }
        else {
            callback(null, data);
        }
    });
}

//sendQRatingDropped
exports.sendQRatingDropped = function (Qname, Qrole, email, address, city, state, mobile, avgRating, callback) {
    transVerification.sendMail({
        to : "HR@theqnowapp.com",
        from : "info@theqnowapp.com",
        subject : "Q Rating dropped",
        replyTo : "info@theqnowapp.com",
        html: QRatingDroppedEmail.emailHR.format(Qname, Qrole, email, mobile, address, city, state, avgRating) // html body
    },
              function (err, data) {
        if (err) {
            callback(err, null);
        }
        else {
            callback(null, data);
        }
    });


}
exports.xmlfortwilio = function (number, callback) {
    var xml =  "<?xml version='1.0' encoding='UTF-8'?>" +
 "<Response>"+
 "<Dial record='true'  callerId='+13107892160'>"+
 "<Number>+"+number+"</Number>"+
 "</Dial>"+
 "</Response>";

callback(null, xml);
//res.header('Content-Type','text/xml').send(xml);


}
