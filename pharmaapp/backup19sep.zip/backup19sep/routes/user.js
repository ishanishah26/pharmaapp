var multer = require('multer');
var express = require('express');
var path = require('path');
var router = express.Router();
var expressJwt = require('express-jwt');
var jwt = require('jsonwebtoken');
var settings = require('./../config/database');
var mail = require('../model/mail.js');
var random;
var user = require('../model/tbluser.js');
var apn = require('../model/apn.js');
var stripeModel = require('../model/tblstripe');
var twilio = require('twilio');

//============================================ change email ==========================

router.put('/changeemail', function (req, res, next) {

    if (req.body.newEmail == "" || req.body.newEmail == undefined) {
        res.json({ status: '0', msg : 'Please enter your new email address.' });
        return;
    }
    random = Math.floor(100000 + Math.random() * 900000);
    var session = res.locals.session;
    user.changeEmail(session.id, req.body.newEmail, random, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'There was an error changing your email.' });
            return;
        }
        else if (data[0][0].msg == "exists") {
            res.json({ status: '0', msg : 'The email address you entered already exists in our database.' });
            return;
        }
        else {
            mail.sendEmail(req.body.newEmail, data[1][0].firstName, random, function (err, data) {
                if (err) {
                    res.json({ status: '1', msg: 'Error sending verification email to new address.' });
                    return;
                }
                else {
                    res.json({ status: '1', msg : 'A verification code was sent to your new email address.' });
                    return;
                }
            });
        }
    });
});

//============================================ verify email =================================

router.post('/passcode', function (req, res, next) {
    var session = res.locals.session;

    if (req.body.passcode == "" || req.body.passcode == undefined) {
      return  res.json({ status: '0', msg : 'Please enter the verification code.' });
    }
    user.verifyPassccode(session.id, req.body.passcode, function (err, data) {

        if (err) {
          return  res.json({ status: '0', msg: 'error' });
        }

        else if ( data.length ) {
          //console.log(data.lenth);
          var mobileNumber = data[0].mobile;
          mobileRandom = Math.floor(100000 + Math.random() * 900000);
          user.resendPasscodeMobile(session.id, mobileRandom, function(err, data){
            if(!err){
              mail.twilioSendMsg(mobileNumber, "Your Q Now mobile phone verification code is " + mobileRandom, function(msgErr,data){

                              if (msgErr)
                              {
                                return   res.json({ status: '0', msg : 'The verification code is not send to your mobile' });
                              }
                              else
                              {

                                  return res.json({ status: '1', msg: 'successfully verified ,otp is send to your mobile' });
                              }
                     });
            }else{
              return   res.json({ status: '0', msg : 'The verification code is not send to your mobile' });
            }
          })

        }
        else  {
        return   res.json({ status: '0', msg : 'The verification code you entered was incorrect.' });
        }
    });
});

//========================================== resend =============================================

router.get('/resend', function (req, res, next) {
    var session = res.locals.session;
    random = Math.floor(100000 + Math.random() * 900000);
    user.resendPasscode(session.id, random, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'error' });
            return;
        }
        else if (data[0][0].mail == "") {
            res.json({ status: '0', msg : 'The email address you entered could not be found.' });
            return;
        }
        else {
            mail.sendEmail(data[0][0].mail, data[0][0].firstName, random, function (err, data) {
                if (err) {
                    res.json({ status: '1', msg: 'Unable to resend verification email. ' + JSON.stringify(err) });
                    return;
                }
                else {
                    res.json({ status: '1', msg : 'The verification code was resent successfully.' });
                    return;
                }
            });
        }
    });
});

//================================================== edit profile ==============================

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/images/')
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + path.extname(file.originalname)) //Appending extensiom
    }
});

var upload = multer({ storage: storage });
router.put('/profilepic', upload.single('image'), function (req, res, next) {
    var path = settings.path;
    var session = res.locals.session;
    if (req.file == "" || req.file == undefined) {
        res.json({ status: '0', msg : 'Please upload a new image.' });
        return;
    }
    else {
        user.profilepic(session.id, req.file.filename, function (err, data) {
            if (err) {
                res.json({ status: '0', msg: 'There was an error uploading your image.' });
                return;
            }
            else if (data.affectedRows > 0) {
                var profile = path.concat("/" + req.file.filename);
                res.json({ status: '1', msg: 'Image Successfully uploaded', image: profile });
                return;
            }
            else {
                res.json({ status: '0', msg: 'userId or token not matched' });
                return;
            }
        });
    }
});

//=============================================== delete Account ============================

router.get('/userDelete', function (req, res, next) {
    var session = res.locals.session;
    user.deleteAccount(session.id, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'error' });
            return;
        }
        else if (data.affectedRows > 0) {
            res.json({ status: '1', msg: 'Your Account has been deleted successfully' });
            return;
        }
        else {
            res.json({ status: '0', msg: 'The email address could not be found.' });
            return;
        }
    });
});

//========================================== report issue ========================================

router.post('/reportIssue', function (req, res, next) {
    var session = res.locals.session;
    if (req.body.issue == "" || req.body.issue == undefined) {
        res.json({ status: '0', msg : 'Please describe your issue.' });
        return;
    }
    else {
        user.reportIssue(session.id, req.body.issue, function (err, data) {
            if (err) {
                res.json({ status: '0', msg: 'There was an error reporting your issue.' });
                return;
            }
            else if (data[0].affectedRows > 0) {

                var fullName = data[1][0].firstName + " " + data[1][0].lastName;
                mail.sendReportEmail(fullName, req.body.issue, data[1][0].email, function (err, data) {
                    if (err) {
                        res.json({ status: '1', msg: 'error in sending mail' });
                        return;
                    }
                    else {
                        res.json({ status: '1', msg : 'Your issue was reported successfully.' });
                        return;
                    }
                });





                //res.json({ status: '1', msg: 'Issue submitted' });
                //return;
            }
            else {
                res.json({ status: '0', msg: 'Problem in reporting issue please try again' });
                return;
            }
        });
    }
});

//============================================= map ======================================

router.post('/location', function (req, res, next) {
    if (req.body.Lat == "" || req.body.Long == "" || req.body.Lat == undefined || req.body.Long == undefined) {
        res.json({ status: '0', msg: 'please provide Lat Long' });
        return;
    }
    var session = res.locals.session;
    user.location(session.id, req.body.Lat, req.body.Long, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'error in updating location' });
            return;
        }
        else if (data.length > 0) {
            res.json({ status: '1', msg: 'Q location' , location: data });
            return;
        }
        else {
            res.json({ status: '0', msg: 'no Q Provider is online' });
            return;
        }
    });
});

//============================================= card Detail ======================================

router.post('/userCard', function (req, res, next) {
    if (req.body.token == "" || req.body.cardNumber == "" || req.body.token == undefined || req.body.cardNumber == undefined) {
        res.json({ status: '0', msg: 'Please enter your credit card information.' });
        return;
    }
    var session = res.locals.session;
    user.userCard(session.id, req.body.token, req.body.cardNumber, function (err, data) {
        if (err) {
           res.json({ status: '0', msg: 'There was an error updating your credit card information.' });
            // res.json({ status: '0', msg: JSON.stringify(err) });
            return;
        }
        else if (data.id != "") {
            res.json({ status: '1', msg: 'Your credit card information was updated successfully.' });
            return;
        }
        else {
            res.json({ status: '0', msg: 'please try again' });
            return;
        }
    });
});

router.post('/validateCard', function (req, res, next) {

    var session = res.locals.session;

    res.json({ status: '1', msg: 'Card Successfully pre charged.' });
    
});




//============================================= change email from profile ======================================

router.post('/changeProfileEmail', function (req, res, next) {
    if (req.body.newEmail == "" || req.body.newEmail == undefined) {
        res.json({ status: '0', msg: 'Please enter your new email address.' });
        return;
    }
    random = Math.floor(100000 + Math.random() * 900000);
    var session = res.locals.session;
    user.changeProfileEmail(session.id, random, req.body.newEmail, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'Error updating your email address.' });
            return;
        }
        else if (data[0][0].msg == 'exists') {
            res.json({ status: '0', msg : 'The email address you entered already exists in our database.' });
            return;
        }
        else {
            mail.sendEmail(req.body.newEmail, data[1][0].firstName, random, function (err, data) {
                if (err) {
                    res.json({ status: '1', msg: 'Error sending email verification code.' });
                    return;
                }
                else {
                    res.json({ status: '1', msg : 'The verification code was sent successfully' });
                    return;
                }
            });
        }
    });
});

//============================================= resend change email from profile ======================================

router.get('/resendPasscodeEmail', function (req, res, next) {
    random = Math.floor(100000 + Math.random() * 900000);
    var session = res.locals.session;
    user.resendPasscodeEmail(session.id, random, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'Error resending verification code.' });
            return;
        }
        else {
            mail.sendEmail(data[1][0].changedEmail, data[1][0].firstName, random, function (err, data) {
                if (err) {
                    res.json({ status: '1', msg: 'Error resending email verification code.' });
                    return;
                }
                else {
                    res.json({ status: '1', msg : 'The verification code was sent successfully' });
                    return;
                }
            });
        }
    });
});

//============================================ verify mobile passcode =================================

router.post('/mobilePasscode', function (req, res, next) {
    var session = res.locals.session;
    if (req.body.passcode == "" || req.body.passcode == undefined) {
        res.json({ status: '0', msg : 'Please enter your text verification code.' });
        return;
    }
    user.verifyMobilePasscode(session.id, req.body.passcode, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'error' });
            return;
        }
        else if (data.affectedRows > 0) {
            res.json({ status: '1', msg: 'successfully verified' });
            return;
        }
        else {
            res.json({ status: '0', msg : 'The text verification code you entered was incorrect. Please try again.' });
            return;
        }
    });
});


//============================================= update email after verify ======================================

router.post('/updateEmail', function (req, res, next) {
    if (req.body.passcode == "" || req.body.passcode == undefined) {
        res.json({ status: '0', msg: 'Please enter the email verification code.' });
        return;
    }
    var session = res.locals.session;
    user.updateEmail(session.id, req.body.passcode, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'Error update your email address.' });
            return;
        }
        else if (data.affectedRows > 0) {
            res.json({ status: '1', msg : 'Your email was changed successfully.' });
            return;
        }
        else {
            res.json({ status: '0', msg: 'Incorrect passcode, Please try again' });
            return;
        }
    });
});

//============================================= change number from profile ======================================

router.post('/changeProfileMobile', function (req, res, next) {
    if (req.body.newMobile == "" || req.body.newMobile == undefined) {
        res.json({ status: '0', msg: 'Please enter your new mobile number.' });
        return;
    }
    random = Math.floor(100000 + Math.random() * 900000);
    var session = res.locals.session;
    user.changeProfileMobile(session.id, random, req.body.newMobile, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'Error updating your mobile number.' });
            return;
        }
        else {
            mail.twilioSendMsg(req.body.newMobile, "Your Q Now mobile phone verification code is " + random, function (err, data) {
                if (err) {
                    console.log(err);
                    res.json({ status: '0', msg: 'The verification code was not sent successfully' });
                    return;
                }
                else {
                    res.json({ status: '1', msg: 'The verification code was sent successfully' });
                    return;
                }
            });
        }
    });
});

//============================================= resend number from profile ======================================

router.get('/resendPasscodeMobile', function (req, res, next) {
    random = Math.floor(100000 + Math.random() * 900000);
    var session = res.locals.session;
    user.resendPasscodeMobile(session.id, random, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'There was an error resending the mobile verification code.' });
            return;
        }
        else {
            mail.twilioSendMsg(data[1][0].mobile, "Your Q Now mobile phone verification code is " + random, function (err, data) {
                if (err) {
                    console.log(err);
                    res.json({ status: '1', msg: 'The verification code was not sent' });
                    return;
                }
                else {
                    res.json({ status: '1', msg: 'The verification code was sent successfully' });
                    return;
                }
            });
        }
    });
});

//============================================= UPDATE MOBILE NUMBER AFTER VERIFY ======================================

router.post('/updateMobile', function (req, res, next) {
    if (req.body.passcode == "" || req.body.passcode == undefined) {
        res.json({ status: '0', msg: 'Please enter the text verification code.' });
        return;
    }
    var session = res.locals.session;
    user.updateMobile(session.id, req.body.passcode, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'Error updating your mobile number.' });
            return;
        }
        else if (data.affectedRows > 0) {
            res.json({ status: '1', msg : 'Your mobile number was changed successfully.' });
            return;
        }
        else {
            res.json({ status: '0', msg: 'The text verification code you entered was incorrect. Please try again.' });
            return;
        }
    });
});


//============================================= UPDATE MOBILE NUMBER AFTER VERIFY ======================================

router.post('/totalCompletedRequestbyQ', function (req, res, next) {
    var session = res.locals.session;
    user.totalCompletedRequest(session.id, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'error in updating location' });
            return;
        }
        else {
            res.json({ status: '1', request: data[0] });
            return;
        }
    });
});

//====================== retrive card details ===========================

router.get('/userCardDetails', function (req, res, next) {
    var session = res.locals.session;
    stripeModel.stripeCardDetails(session.id, function (err, data) {
        if (err) {
            next(err);
            return;
        }
        else {
            res.json(200, data);
            return;
        }
    });
});

//====================== get twilio capability token ===========================

router.get('/getTwilloCapability', function (req, res, next) {
    var capability = new twilio.Capability(settings.TwilioAccountId, settings.TwilioAuthToken);
    var capabilityToken;
    // Give the capability generator permission to make outbound calls
    capability.allowClientOutgoing('APd561fb2ef016e9a3f02310e8f01db803');
    capability.allowClientIncoming('qapp');
    try {
        capabilityToken = capability.generate();
    }
	catch (err) {
        console.log(err.message);
    }
    return res.json(200, { token: capabilityToken });
});

module.exports = router;
