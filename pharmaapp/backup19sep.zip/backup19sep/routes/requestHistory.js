var multer = require('multer');
var express = require('express');
var path = require('path');
var router = express.Router();
var expressJwt = require('express-jwt');
var jwt = require('jsonwebtoken');
var settings = require('./../config/database');
var mail = require('../model/mail.js');
var random;
var request = require('../model/tblreqesthistory.js');
var provider = require('../model/tblprovider.js');

//======================================= Show request Accepted List =====================================

router.post('/requestAcceptedList', function (req, res, next) {
    if (req.body.qId == "" || req.body.qId == undefined) {
        res.json({ status: '0', msg: 'please enter qId' });
        return;
    }
    request.showRequestAccepted(req.body.qId, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'No History found' });
            return;
        }
        else if (data.length > 0) {

            var path = settings.path;
            for (var i = 0; i < data.length; i++) {

                var profilePic = "";
                if (data[i].userProfile != null){
                    profilePic = path.concat(data[i].userProfile);
                }
                data[i].userProfile = profilePic;

                var date = data[i].createdDate + "";
                var train_date = date.split(" ");
                data[i].createdDate = train_date[2] + " " + train_date[1] + " " + train_date[3];
                data[i].mapURL=path.concat(data[i].mapURL);
            }
            res.json({ status: '1', acceptedList: data });
            return;
        }
        else {
            res.json({ status: '2', msg: 'No History found' });
            return;
        }
    });
});

//======================================= request history =====================================

/*router.get('/requestHistory', function (req, res, next) {
    var session = res.locals.session;
    request.requestHistory(session.id, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'Your request history could not be retrieved. Please try again.' });
            return;
        }
        else if (data.length > 0) {
            var submitted = [];
            var completed = [];
            var canceled = [];
            var j = 0;
            var k = 0;
            var l = 0;
            var path = settings.path;
            for (var i = 0; i < data.length; i++) {
                var profilePic = "", stopMarkers="";
                if (data[i].userProfile != null){
                    profilePic = path.concat(data[i].userProfile);
                }

                data[i].userProfile = profilePic;
                var isTransport = data[i].isTransport.toString();
                data[i].isTransport = isTransport;
                var date = data[i].createdDate + "";
                var train_date = date.split(" ");
                data[i].createdDate = train_date[2] + " " + train_date[1] + " " + train_date[3];
                data[i].mapURL=path.concat(data[i].mapURL);
                if (data[i].requestStatus == "1" || data[i].requestStatus == "2") {
                    submitted[j] = data[i];
                    j++;
                }
                else if (data[i].requestStatus == "3") {
                    completed[k] = data[i];
                    k++;
                }
                else {
                    canceled[l] = data[i];
                    l++;
                }
            }
            res.json({ status: '1', msg: 'Get your History', submitted: submitted, completed: completed, canceled: canceled });
            return;
        }
        else {
            res.json({ status: '2', msg: 'sorry, No History found' });
            return;
        }
    });
});*/
router.get('/requestHistory', function (req, res, next) {
    var session = res.locals.session;
    request.requestHistory(session.id, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'Your request history could not be retrieved. Please try again.' });
            return;
        }
        else if (data.length > 0) {
            
           var path = settings.path;
            for (var i = 0; i < data.length; i++) {
                var profilePic = "", stopMarkers="";
                if (data[i].userProfile != null){
                    profilePic = path.concat(data[i].userProfile);
                }

                data[i].userProfile = profilePic;
                var isTransport = data[i].isTransport.toString();
                data[i].isTransport = isTransport;
                var date = data[i].createdDate + "";
                var train_date = date.split(" ");
                data[i].createdDate = train_date[2] + " " + train_date[1] + " " + train_date[3];
                data[i].mapURL=path.concat(data[i].mapURL);
                         }
            res.json({ status: '1', msg: 'Get your History', data :data });//submitted: submitted, completed: completed, canceled: canceled });
            return;
        }
        else {
            res.json({ status: '2', msg: 'sorry, No History found' });
            return;
        }
    });
});


//======================================= q request Review =====================================

router.post('/qRequestReview', function (req, res, next) {
    if (req.body.qRequestId == "" || req.body.qRequestId == undefined || req.body.speedRating == "" || req.body.speedRating == undefined || req.body.qualityRating == "" || req.body.qualityRating == undefined) {
        res.json({ status: '0', msg: 'Please review your Q.' });
        return;
    }
    request.qRequestReview(req.body.qRequestId, req.body.speedRating, req.body.qualityRating, req.body.feedback, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'There was an error submitting your review.' });
            return;
        }
        else {
            res.json({ status: '1', msg: 'Review submited successfully' });
            provider.qdetailsandreviewbyid(req.body.qRequestId, function (err, data) {
                if (!err) {
                    if(data[0].averageRating < 2.5){//if avgRating <= 3 Send mail to HR@theQNowapp.com with Q details
                        var rating;
                        if(data[0].averageRating >= 1.5 && data[0].averageRating < 2.5){
                            rating = "C";
                        }else if(data[0].averageRating >= 0.5 && data[0].averageRating < 1.5){
                            rating = "D";
                        }else if(data[0].averageRating < 0.5){
                            rating = "F";
                        }
                        mail.sendQRatingDropped(data[0].firstName + " " + data[0].lastName, data[0].roleOfQ, data[0].email, data[0].address, data[0].city, data[0].state, data[0].mobile, rating, function (err, data) {
                            if (err) {
                                console.log(err);
                            }
                        });
                    }
                }
            });
            return;
        }
    });
});

//======================================= request history =====================================

router.post('/requestHistoryId', function (req, res, next) {
    var session = res.locals.session, userCardNumber = "", stopMarkers= "", requestMarkers= "";
    request.requestHistoryId(session.id, req.body.qRequestId, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'Unable to display request history.' });
            return;
        }
        else if (data.length > 0) {
            var stops = [];
            var path = settings.path;
            var profilePic = "";
            var cProfilePic ="";

            if (data[0][0].userProfile == null) {
               profilePic = "user-profile.png";
            }
            else {
                var profilePic = path.concat(data[0][0].userProfile);
            }

            if (data[0][0].cUserPrifile == null) {
               cProfilePic = "";
            }
            else {
                cProfilePic = path.concat(data[0][0].cUserPrifile);
            }
            if (data[1].length > 0) {
                userCardNumber = data[1][0].cardNumber;
            }
            if (data[0][0].isTransport == 1) {
                for (var i = 0; i < data[0].length; i++) {
                    stops[i] = {
                        "Lat": data[0][i].stopLat,
                        "Long": data[0][i].stopLong,
                        "Address": data[0][i].address
                    }
                }
                var request = {

                    "qId": (data[0][0].qId == null ? "" : data[0][0].qId),
                    "isTransport": data[0][0].isTransport.toString(),
                    "requestVerb": data[0][0].requestVerb,
                    "requestNoun": data[0][0].requestNoun,
                    "qRequiredTime_Hr": data[0][0].qRequiredTime_Hr,
                    "qRequiredPayment": data[0][0].qRequiredPayment,
                    "numberOfStops": data[0][0].numberOfStops.toString(),
                    "createdDate": data[0][0].createdDate,
                    "requestStatus": data[0][0].requestStatus.toString(),
                    "firstName": (data[0][0].firstName == null ? "" : data[0][0].firstName),
                    "lastName": (data[0][0].lastName == null ? "" : data[0][0].lastName),
                    "email": (data[0][0].email == null ? "" : data[0][0].email),
                    "mobile": (data[0][0].mobile == null ? "" : data[0][0].mobile),
                    "userProfile": profilePic,
                    "stops": stops,
                    "baseRate": data[0][0].baseRate,
                    "distanceFee": (data[0][0].distanceFee == null ? "" : data[0][0].distanceFee),
                    "distanceTravelled": (data[0][0].milesTransported == null ? "" : data[0][0].milesTransported),
                    "timeElapsed": (data[0][0].timeElapsed == null ? "" : data[0][0].timeElapsed),
                    "QAdminFee": (data[0][0].QAdminFee == null ? "" : data[0][0].QAdminFee),
                    "reimbursementAmount": (data[0][0].reimbursementAmount == null ? "" : data[0][0].reimbursementAmount),
                    "subTotal": (data[0][0].subTotal == null ? "" : data[0][0].subTotal),
                    "totalPayment": (data[0][0].totalPayment == null ? "" : data[0][0].totalPayment),
                    "TotalPaymentToQ": (data[0][0].TotalPaymentToQ == null ? "" : data[0][0].TotalPaymentToQ),
                    "userCardNumber": (userCardNumber == null ? "" : userCardNumber),
                    "receiptTotalBill" :data[0][0].receiptTotalBill ,
                    "paymentDoneByRequestor" : data[0][0].paymentDoneByRequestor ,
                    "paymentReceivedByQ" :data[0][0].paymentReceivedByQ ,
                    "requestAmt" : data[0][0].requestAmt ,
                    "serviceFeeToQ" :data[0][0].serviceFeeToQ ,
                    "serviceFeeToUser" : data[0][0].serviceFeeToUser ,
                    "mapURL": (data[0][0].mapURL == "" ? "" : path.concat(data[0][0].mapURL)),


                };
                res.json({ status: '1', Q: request });
                return;
            }
            else {
                if (data[0][0].qRequiredDate != '0000-00-00') {
                    var date = data[0][0].qRequiredDate + "";
                    var train_date = date.split(" ");
                    data[0][0].qRequiredDate = train_date[2] + " " + train_date[1] + " " + train_date[3];
                }
                var request = {
                    "qId": (data[0][0].qId == null ? "" : data[0][0].qId),
                    "isTransport": data[0][0].isTransport.toString(),
                    "requestVerb": data[0][0].requestVerb,
                    "requestNoun": data[0][0].requestNoun,
                    "qRequiredTime_Hr": data[0][0].qRequiredTime_Hr,
                    "qRequiredPayment": data[0][0].qRequiredPayment,
                    "isRequiredNow": data[0][0].isRequiredNow.toString(),
                    "qRequiredDate": data[0][0].qRequiredDate,
                    "createdDate": data[0][0].createdDate,
                    "requestStatus": data[0][0].requestStatus.toString(),
                    "firstName": (data[0][0].firstName == null ? "" : data[0][0].firstName),
                    "lastName": (data[0][0].lastName == null ? "" : data[0][0].lastName),
                    "email": (data[0][0].email == null ? "" : data[0][0].email),
                    "mobile": (data[0][0].mobile == null ? "" : data[0][0].mobile),
                    "userProfile": profilePic,
                    "cFirstName" :data[0][0].cFirstName ,
                    "cLastName" : data[0][0].cLastName ,
                    "cUserProfile" : cProfilePic,
                    "baseRate": data[0][0].baseRate,
                    "timeElapsed": (data[0][0].timeElapsed == null ? "" : data[0][0].timeElapsed),
                    "QAdminFee": (data[0][0].QAdminFee == null ? "" : data[0][0].QAdminFee),
                    "reimbursementAmount": (data[0][0].reimbursementAmount == null ? "" : data[0][0].reimbursementAmount),
                    "subTotal": (data[0][0].subTotal == null ? "" : data[0][0].subTotal),
                    "totalPayment": (data[0][0].totalPayment == null ? "" : data[0][0].totalPayment),
                    "TotalPaymentToQ": (data[0][0].TotalPaymentToQ == null ? "" : data[0][0].TotalPaymentToQ),
                    "userCardNumber": (userCardNumber == null ? "" : userCardNumber),
                    "receiptTotalBill" :data[0][0].receiptTotalBill ,
                    "paymentDoneByRequestor" : data[0][0].paymentDoneByRequestor ,
                    "paymentReceivedByQ" :data[0][0].paymentReceivedByQ ,
                    "requestAmt" : data[0][0].requestAmt ,
                    "serviceFeeToQ" :data[0][0].serviceFeeToQ ,
                    "serviceFeeToUser" : data[0][0].serviceFeeToUser ,
                    "mapURL": (data[0][0].mapURL == "" ? "" : path.concat(data[0][0].mapURL)),
                    "lat":data[0][0].currentLat,
                    "long":data[0][0].currentLong
                };
                res.json({ status: '1', Q: request });
                return;
            }
        }
        else {
            res.json({ status: '0', msg: 'no data found for this id' });
            return;
        }
    });
});

//======================================= q request Review =====================================

router.post('/sendText1', function (req, res, next) {
    if (req.body.toNumber == "" || req.body.toNumber == undefined || req.body.fromNumber == "" || req.body.fromNumber == undefined || req.body.msg == "" || req.body.msg == undefined) {
        res.json({ status: '0', msg: 'please provide data' });
        return;
    }
    mail.twilioSendMsgForUser1(req.body.toNumber, req.body.fromNumber, req.body.msg, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'There was an error sending your text.' });
            return;
        }
        else {
            res.json({ status: '1', msg: 'Text sent successfully.' });
            return;
        }
    });
}); 

router.post('/sendText', function (req, res, next) {
	console.log("tonumber"+ req.body.toNumber);
		console.log("tonumber"+ req.body.fromNumber);
    if (req.body.toNumber == "" || req.body.toNumber == undefined || req.body.fromNumber == "" || req.body.fromNumber == undefined || req.body.msg == "" || req.body.msg == undefined ||req.body.requestid =="" ||req.body.requestid == undefined) {
        res.json({ status: '0', msg: 'please provide data' });
        return;
    }
    mail.twilioSendMsgForUser(req.body.toNumber, req.body.fromNumber, req.body.msg,req.body.requestid, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'There was an error sending your text.' });
            return;
        }
        else {
            res.json({ status: '1', msg: 'Text sent successfully.' });
            return;
        }
    });
});

module.exports = router;
