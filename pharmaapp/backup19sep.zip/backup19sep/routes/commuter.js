var twilio = require('twilio');
var express = require('express');
var router = express.Router();
var modelc= require('../model/modelcommuter.js');

// POST: /commuter/use-sms
router.post('/smsReply', twilio.webhook({ validate: false }), function (req, res) {
  from = req.body.From;
  to   = req.body.To;
  body = req.body.Body;
	var twiml = new twilio.TwimlResponse();
	console.log("--in sms rpl-----");
	console.log(twiml);
	console.log("from:-"+req.body.From);
	console.log("body:-"+req.body.Body);
	console.log("to:-"+req.body.To);
	tono=req.body.To;
	fromno1=req.body.From;
	messagebody=req.body.Body;
	var receipterNo="";
	var fromno = fromno1.substring(2);
	console.log("from no:-"+fromno);
	modelc.smsReply(tono,function(err,data){
	if(err){
	console.log(err);
	}
	else
	{

	 var Qprovidermobile = data[1][0].Qprovidermobile;
		console.log("Q"+Qprovidermobile);
          var userno =data[2][0].usermobile;
		console.log("user"+userno);

		if(fromno == Qprovidermobile || fromno == userno)
		{
			if(fromno == userno)
			{
				//console.log("in if");
				receipterNo=Qprovidermobile;
			}
			else
			{
				//console.log("in else");
				receipterNo=userno;
			}




	}
	console.log("receipterNo:-"+receipterNo);
	var twiml = new twilio.TwimlResponse();
   	twiml.message(body, { to: receipterNo  });

    	res.type('text/xml');
    	res.send(twiml.toString());
	console.log("message send successfully");
	}
	});

});

// POST: /commuter/use-voice
router.post('/voiceReply', twilio.webhook({ validate: false }), function (req, res) {
  from = req.body.From;
  to   = req.body.To;
  body = req.body.Body;
});
module.exports = router;
