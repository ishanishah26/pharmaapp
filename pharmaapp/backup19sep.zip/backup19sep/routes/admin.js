var express = require('express');
var router = express.Router();
var tblqProviderModel = require('../model/tblprovider.js');
var tblUserModel = require('../model/tbluser');
var user = require('../model/tblregister.js');
var promo = require('../model/modelpromo.js');
//====================promo code====================
router.get('/promocode', function (req, res) {
   sess = req.session;
    if (sess.email) {
      promo.getpromo(function(err,data){
              if(!err){
            res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
            return res.render('promocode',{data:data});
          }
          else {
            res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
            return res.json(422, err);
          }

    });
  }
    else {
        res.render('AdminPanel', { title: "Admin Panel", errorName: "Not Logged in" , errorMessage : "Please login first to view page", errorVisibility: "normal" , forget: "false"})
    }
});
router.post('/deletepromo',function(req,res){
  sess = req.session;
   if (sess.email) {
promo.deletepromo(req.body.promoId,function(err,data){
      if(!err){
      res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
      return res.json(200, data)
  }
  else {
    console.log(err);
    res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
    return res.json(422, err);
  }
});
}
  else {
      res.render('AdminPanel', { title: "Admin Panel", errorName: "Not Logged in" , errorMessage : "Please login first to view page", errorVisibility: "normal" , forget: "false"})
  }
});

router.post('/createpromocode',function(req,res){
 // sess = req.session;
 //  if(sess.email){
    promo.createpromo(req.body.promocode,function(err,data){
      if(!err)
      {
        res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
        //return res.send('Promocode Inserted');
        return res.json(200, data);
      }
      else {
        res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
        return res.json(422, err);
      }
    });

  // }
  // else {
  //     res.render('AdminPanel', { title: "Admin Panel", errorName: "Not Logged in" , errorMessage : "Please login first to view page", errorVisibility: "normal" , forget: "false"})
  // }
});
//==================dashboard============
router.get('/AdminDashBoard', function (req, res) {
    sess = req.session;
    if (sess.email) {
            res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
            return res.render('AdminPanelHome.ejs', { "email": sess.email });
    }
    else {
        res.render('AdminPanel', { title: "Admin Panel", errorName: "Not Logged in" , errorMessage : "Please login first to view page", errorVisibility: "normal" , forget: "false"})
    }
});

router.get('/AdminPanel', function (req, res) {
    if (req.session) {
        res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
        return res.render('AdminPanelHome.ejs', { "email": sess.email });
    } else {
        res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
        res.render('AdminPanel', { title: "Admin Panel", errorName: "" , errorMessage : "", errorVisibility: "none", forget: "false" })
    }
});

router.get('/QList', function (req, res) {
    sess = req.session;
    if (sess.email) {
        tblqProviderModel.qlist(function (err, qlist) {
            res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
            return res.render('QList', { QList: qlist })
        });
    }
    else {
        res.render('AdminPanel', { title: "Admin Panel", errorName: "Not Logged in" , errorMessage : "Please login first to view page", errorVisibility: "normal" , forget: "false"})
    }
});

//QUpdate
router.post('/QUpdate', function (req, res) {
    sess = req.session;
    if (sess.id) {

		tblqProviderModel.updateStatus(req.body.qId, req.body.isActive, res.connection.remoteAddress, function (err, data) {
			if (!err) {
				res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
				return res.json(200, data)
			} else {
				res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
				return res.json(422, err);
			}
        });
    }
    else {
        res.render('AdminPanel', { title: "Admin Panel", errorName: "Not Logged in" , errorMessage : "Please login first to view page", errorVisibility: "normal", forget: "false" })
    }
});

//UpdateQ
router.post('/UpdateQ', function (req, res) {
    sess = req.session;
    if (sess.id) {
		tblqProviderModel.UpdateQ(req.body.qId, req.body.firstName, req.body.lastName,
                                    req.body.email, req.body.address, req.body.city, req.body.state,
                                    req.body.zipCode, req.body.mobile, req.body.nameOnDL,
                                    req.body.socialSecurityNo, req.body.dateOfBirth, req.body.dlNo,
                                    req.body.dlState, req.body.dlDateExpiration, req.body.totalYearOfProfExp,
                                    req.body.personalAssistantExp, req.body.roleOfQ, req.body.isActive,
                                    req.body.isQOnline, function (err, data) {
			if (!err) {
				res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
				return res.json(200, data)
			} else {
				res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
				return res.json(422, err);
			}
        });
    }
    else {
        res.render('AdminPanel', { title: "Admin Panel", errorName: "Not Logged in" , errorMessage : "Please login first to view page", errorVisibility: "normal", forget: "false" })
    }
});
router.get('/map',function(req,res){
    console.log("event call");
    sess = req.session;
    if (sess.email)
    {
        tblqProviderModel.QProvider(function (err, data) {
            res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
            return res.render('map.ejs', { QProviders: data })
        });
    }
    else
    {
        res.render('AdminPanel', { title: "Admin Panel", errorName: "Not Logged in" , errorMessage : "Please login first to view page", errorVisibility: "normal", forget: "false" })
    }
});

//deleteQ
router.post('/deleteQ', function (req, res) {
    sess = req.session;
    if (sess.id) {
		tblqProviderModel.deleteQ(req.body.qId, function (err, data) {
			if (!err) {
				res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
				return res.json(200, data)
			} else {
				res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
				return res.json(422, err);
			}
        });
    }
    else {
        res.render('AdminPanel', { title: "Admin Panel", errorName: "Not Logged in" , errorMessage : "Please login first to view page", errorVisibility: "normal" , forget: "false"})
    }
});


router.post('/QUpdateService', function (req, res) {
    sess = req.session;
    if (sess.id) {

		tblqProviderModel.updateService(req.body.qId, req.body.service, function (err, data) {
			if (!err) {
				res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
				return res.json(200, data)
			} else {
				res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
				return res.json(422, err);
			}
        });
    }
    else {
        res.render('AdminPanel', { title: "Admin Panel", errorName: "Not Logged in" , errorMessage : "Please login first to view page", errorVisibility: "normal", forget: "false" })
    }
});


//UpdateUserStatus
router.post('/userUpdateStatus', function (req, res) {
    sess = req.session;
    if (sess.id) {

		tblUserModel.updateAccountStatus(req.body.userId, req.body.isActive, function (err, data) {
			if (!err) {
				res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
				return res.json(200, data)
			} else {
				res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
				return res.json(422, err);
			}
        });
    }
    else {
        res.render('AdminPanel', { title: "Admin Panel", errorName: "Not Logged in" , errorMessage : "Please login first to view page", errorVisibility: "normal", forget: "false" })
    }
});


//GetUsersList
router.get('/usersList', function (req, res) {
    sess = req.session;
    if (sess.email) {
        tblUserModel.getUsersList(function (err, usersList) {
            res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
            return res.render('Users', { userList: usersList })
        });
    }
    else {
        res.render('AdminPanel', { title: "Admin Panel", errorName: "Not Logged in" , errorMessage : "Please login first to view page", errorVisibility: "normal" , forget: "false"})
    }
});


//checkQStripeAccount
router.post('/checkQStripeAccount', function (req, res) {
    sess = req.session;
    if (sess.email) {
        tblqProviderModel.checkQStripeAccount(req.body.qId, function (err, qlist) {
            res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
            return res.send({ QList: qlist })
        });
    }
    else {
        res.render('AdminPanel', { title: "Admin Panel", errorName: "Not Logged in", errorMessage: "Please login first to view page", errorVisibility: "normal", forget: "false" })
    }
});

//==============================q Details=============================================

router.post('/getDetailsOfQ', function (req, res, next) {
    if (req.body.qId == "" || req.body.qId == null) {
        res.json(400, { error : 'please provide qId' });
        return;
    }
    tblqProviderModel.qdetailsbyid(req.body.qId, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'error' });
            return;
        }
        else {
             for(i=0;i<data.lenght;i++){
               data[i].socialSecurityNo=encryptor.decrypt(data[i].socialSecurityNo);
               data[i].dlNo=encryptor.decrypt(data[i].dlNo);
               data[i].address=encryptor.decrypt(data[i].address);
             }
            res.json(200, data);
            return;
        }
    });
});

//logout
router.get('/logout', function (req, res) {
    req.session.destroy(function (err) {
        if (err)
            console.log(err);
        else
            res.redirect('/');
    });
});
//Rendering views done

router.get('/*', function (req, res) {
    sess = req.session;
    if (sess.email) {
        res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
        return res.render('AdminPanelHome.ejs', { "email": sess.email });
    }
    else {
        res.render('AdminPanel', { title: "Admin Panel", errorName: "Not Logged in" , errorMessage : "Please login first to view page", errorVisibility: "normal" , forget: "false"})
    }
});
module.exports = router;
