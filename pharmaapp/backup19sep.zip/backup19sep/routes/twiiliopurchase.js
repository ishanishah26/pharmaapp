var express = require('express');
var router = express.Router();
var twilio = require('twilio');
//var client = twilio('ACCOUNT_SID', 'AUTH_TOKEN');
 var client =twilio('ACac1adfd7285efc0563531146a9bf379f','39d3aadc66471306e5aac6f5d7e4ac95');
// See if we have any phone numbers in the 651 area code...
client.incomingPhoneNumbers.list({
    phoneNumber:'+1651*******'
}, function(listError, listResults) {
    if (listError) {
        console.error('Ruh roh - couldn\'t list numbers because: '+listError.message);
    } else {
        // Check if we have any...
        if (listResults.incomingPhoneNumbers.length === 0) {
            // Buy a US phone number in the 651 area code using callbacks
            client.availablePhoneNumbers('US').local.get({
                areaCode:'651'
            }, function(searchError, searchResults) {
 
                // handle the case where there are no numbers found
                if (searchResults.availablePhoneNumbers.length < 1) {
                    console.error('Oh noes! There are no 651 phone numbers!');
                } else {
 		console.log("---available no---------");
		console.log(searchResults.availablePhoneNumbers);
		console.log("----list complete--------");
                    // Buy the first phone number we found
                    client.incomingPhoneNumbers.create({
                        phoneNumber:searchResults.availablePhoneNumbers[0].phoneNumber,
                          voiceUrl:'http://198.61.223.30/voiceReply',
                       smsUrl:'http://198.61.223.30/smsReply'
                    }, function(buyError, number) {
                        if (buyError) {
                            console.error('Buying the number failed. Reason: '+buyError.message);
                        } else {
                            console.log('Number purchased! Phone number is: '+number.phoneNumber);
                        }
                    });
                }
 
            });
        }
    }
});
module.exports = router;
