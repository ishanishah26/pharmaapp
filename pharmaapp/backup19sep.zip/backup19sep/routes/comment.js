<!DOCTYPE html>
<html lang="en">
<head>
    <% include ./head %>
    <style>
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            margin: 0;
        }
        .modal-body {
            max-height: calc(100vh - 210px);
            overflow-y: auto;
        }
        .alert {
            display: none;
        }

        .textboxError {
            width: 50px;
            color: red;
        }
        .modal1 {
            display: none;
            position: fixed;
            z-index: 1000000;
            top: 0;
            left: 0;
            height: 100%;
            width: 100%;
            background: rgba( 255, 255, 255, .8 ) url('static_image/loader.gif') 50% 50% no-repeat;
        }
        body.loading {
            overflow: hidden;
        }
    body.loading .modal1 {
                display: block;
        }
        input#promocode{ width: 66% !important; margin: 0 0 10px 0;}
        .input-div{ margin: 0 0 20px 0;}
    </style>
    <script>
    var APIURL;
  //  APIURL="http://198.61.223.30/";
   APIURL="http://localhost:3000/";
    $(document).ready(function() {


      var rootdiv = $("#cbVerified").closest("div");
      rootdiv.width(100);
      var options = '<thead>';
      options += '<tr><th>promoId</th><th>Promo phrase</th><th>CreatedDate</th><th>promocode Active</th><th>Delete promocode</th></tr>' ;
      options += '</thead><tbody>';
        <% for (i = 0; i < data.length; i++){ %>
          options += '<tr eid="<%= i %>">';
                  options += '<th><%= data[i].promoid%></th>';
                  //options += '<th><%= data[i].promocodePhase%></th>';
                  options += '<th><a class="promoupdate" style="cursor:pointer; text-decoration: none;" promoid="<%=data[i].promoid%>" promop="<% data[i].promocodePhase%>" date="<%= data[i].createdDate%>" status="<%= data[i].isActive%>" ><%= data[i].promocodePhase %></a></th>' ;
                  options += '<th><%= data[i].createdDate%></th>';
                  var date="<%= data[i].createdDate%>";
                  var status = "<%= data[i].isActive%>";
                  if(status == 1)
                      options += '<th><input class="userStatusSwitch" checked type="checkbox" class="toggle btn on btn-primary" data-toggle="toggle" promoId="<%= data[i].promoid%>" Status="0" id="cbStatusId<%= data[i].promoid%>" data-on="Active" data-off="Inactive" data-offstyle="warning" data-size="mini"></th>';
                  else
                  options += '<th><input class="userStatusSwitch" type="checkbox" class="toggle btn off" data-toggle="toggle" promoId="<%= data[i].promoid%>" cbUserStatus="1" id="cbStatusId<%= data[i].promoid%>" name="cbStatusName<%= data[i].promoid%>" data-on="Active" data-off="Inactive" data-offstyle="warning" data-size="mini"></th>';
                  options += '<th><input class="btn btn-warning btn-xs deleteUserButton" promoId="<%= data[i].promoid%>" onClick="return false;" value="Delete Promocode" readonly></th>';
                  options += '</tr>';
                <% } %>

                  options +='</tbody>';
                  $("#promoList").html(options);
                  $('.StatusSwitch').bootstrapToggle({
                      size: 'mini',
                      width: 100
                  });
                  var tab = $('#promoList').DataTable( {
                      responsive: {
                          details: true
                      }
                     "columnDefs": [
                     { "visible": false, "targets": 0 },
                     { "searchable": false, "targets": [3,4] },
                     { "sortable": false, "targets": [3,4] },

                         ]
                    });

      jQuery('#addpromo').click(function(){
      var code=  $('#promocode').val();
      if(code == ""){
        $('#outModalWarning1').show();
        $('#outModalWarning1').delay(3000).fadeOut("slow");
        }
        else {
          var data = {
            "promocode" : $('#promocode').val()
          }
          callURL=APIURL+"createpromocode";

          $.ajax({
              type: "post",
              url: callURL,
              data: JSON.stringify(data),
              contentType: "application/json",
              success: function (data) {
                $('#outModalSuccess').show();
                $('#outModalSuccess').delay(3000).fadeOut( "slow");
                //$("#promoList").html(options);
                //  $("#promoList").html(options);

              //  $("#datatable").dataTable(settings);
                tab.draw();
              }
              });
     return false;
      }
      });


      $(document).on("click", ".deleteUserButton", function(e){
          var idToDelete = $(this).attr('promoId');
          console.log(idToDelete);
          var trToremove = $(this).closest('tr');
           e.preventDefault();
           $('#confirm').modal('show')
           .one('click', '#btnYes', function (e) {
              Deletepromo(idToDelete,trToremove);
           })
           .one('click', '#btnNo', function (e) {
             $('#confirm').modal('hide');
           });
      });
      function Deletepromo(idToDelete,trToremove){
        var callURL = APIURL + "deletepromo";
          $.ajax({
              type: "POST",
              url: callURL,
              data: JSON.stringify({"promoId" : idToDelete}),
              contentType: "application/json; charset=utf-8",
              success: function (data, status, xhr) {
                  trToremove.hide();
                  trToremove.remove();
                  tab.row(trToremove).remove().draw();
                  $('#outModalWarning').show();
                  $('#outModalWarning').delay(3000).fadeOut( "slow");
              },
              error: function (data) {
                  $('#outModalDanger').html('promocode was not deleted');
                  $('#outModalDanger').show();
                  $('#outModalDanger').delay(3000).fadeOut( "slow");
              }
          })
      }

      $(document).on("change",".userStatusSwitch", function() {
              var userToUpdate = {};
              userToUpdate.userId = $(this).attr('promoId');
              if($(this).is(':checked'))
                  userToUpdate.isActive = 0;
              else
                  userToUpdate.isActive = 1;
              var callURL = APIURL + "UpdateStatus";
              $.ajax({
                  type: "POST",
                  url: callURL,
                  data: JSON.stringify(userToUpdate),
                  contentType: "application/json; charset=utf-8",
                  success: function (data, status) {
                      $('#outModalSuccess').show();
                      $('#outModalSuccess').delay(3000).fadeOut("slow");
                      var chToUpdate = "#cbStatusId" + userToUpdate.userId;
                      $(chToUpdate).attr("cbUserStatus",userToUpdate.isActive);
                  },
                  error: function (data) {
          $('#outModalDanger').html(" User details not updated");
                      $('#outModalDanger').show();
                      $('#outModalDanger').delay(3000).fadeOut( "slow");
                      var chToUpdate = "#cbStatusId" + userToUpdate.userId;
                      //$(chToUpdate).bootstrapToggle('toggle');
                      var rootToggleDiv = $(chToUpdate).closest("div");
                      var userStatus=$(chToUpdate).attr("cbUserStatus");
                      if(userStatus == 0)
                          rootToggleDiv.attr("class","toggle btn btn-primary btn-xs");
                      else if(userStatus == 1)
                          rootToggleDiv.attr("class","toggle btn btn-xs btn-warning off");
                  }
              })
      });

      });
    </script>

</head>
<body class="container">

    <header>
        <% include ./header %>
        <div id="outModalSuccess" class="alert alert-success alert-autocloseable-success">
            Promocode created successfully.
        </div>
        <div id="outModalDanger" class="alert alert-danger alert-autocloseable-danger">
              Promocode not created.
        </div>
        <div id="outModalWarning" class="alert alert-warning alert-autocloseable-warning">
             Promocode deleted.
        </div>
        <div id="outModalWarning1" class="alert alert-warning alert-autocloseable-warning">
             Please enter Promocode.
        </div>

    </header>
    <main>
  <div class="jumbotron">
    <div class="container">
      			 <div class="col-sm-12">


            <div class="text-center input-div">
           <label>Promocode Phrase</label>
             <div class="col-sm-offset-3">
               <input type="text" id="promocode" class="form-control"/>
             </div>
             <button id="addpromo" class="btn btn-primary">Create Promocode</button>
           </div>


           <!-- MODEL -->

            <div class="modal fade bs-example-modal-lg" id="confirm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
               <div class="modal-dialog modal-sm" role="document">
                   <div class="modal-content">
                       <div class="modal-header">
                           <button type="button" id="btnCloseModal" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                           <h4 class="modal-title" id="myModalLabel">Confirmation</h4>
                       </div>
                       <div class="modal-body">
                          are you sure ?
                       </div>
                       <div class="modal-footer">
                           <button type="button" id="btnYes" class="btn  btn-primary" data-dismiss="modal">Yes</button>
                           <button type="button" id="btnNo" class="btn btn-default">No</button>
                       </div>
                   </div>
               </div>
           </div>

           <!--model-->
           <!--dataTable -->
           <div id="TableContainer" class="table-responsive">
               <table id="promoList" class="table table-striped table-bordered table-responsive" cellspacing="0" width="100%"></table>
           </div>
        </div>

        </div>
      </div>
    </main>
    <footer>
        <% include ./footer %>
    </footer>

</body>
</html>
