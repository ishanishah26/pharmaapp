var multer = require('multer');
var express = require('express');
var path = require('path');
var router = express.Router();
var expressJwt = require('express-jwt');
var jwt = require('jsonwebtoken');
var settings = require('./../config/database');
var mail = require('../model/mail.js');
var random;
var provider = require('../model/tblprovider.js');
var stripeModel = require('../model/tblstripe');

//================================================== qProvider ===============================

router.post('/qProvider', function (req, res, next) {
    if (req.body.curLat == "" || req.body.curLong == "" || req.body.fname == "" || req.body.lname == "" || req.body.email == "" || req.body.zipCode == "" || req.body.mobile == "" || req.body.state == "" || req.body.city == "" || req.body.address == "")
    {
        res.json({ status: '0', msg: 'Please enter all required data.' });
        return;
    }
    //random = Math.floor(100000 + Math.random() * 900000);
    var session = res.locals.session;
    provider.qProviderRequest(session.id, req.body.curLat, req.body.curLong, req.body.fname, req.body.lname, req.body.email, req.body.zipCode, req.body.mobile, req.body.address, req.body.city, req.body.state, function (err, data) {
        if (err) {
          console.log(err);
            res.json({ status: '0', msg: 'error' });
            return;
        }
        else if (data[0][0].msg == 'exists') {
            res.json({ status: '0', msg: 'You have already registered as a Q.' });
            return;
        }
        else {
            /*mail.twilioSendMsg(req.body.mobile,random, function(err,data){
                    if (err)
                    {
                        console.log(err);
                    }
                    else
                    {
                        console.log(data);
                    }
           });*/
            res.json({ status: '1', msg: 'You have successfully registered as a Q', qId: data[0][0].qProviderId });
            return;
        }
    });
});

//================================================== qProvider ===============================

router.put('/qProviderLigal', function (req, res, next) {
    if (req.body.lFname == "" || req.body.lLname == "" || req.body.securityNum == "" || req.body.dob == "" || req.body.dlNum == "" || req.body.dlstate == "" || req.body.dlExpiration == "" || req.body.hsInfo == "" || req.body.clgInfo == "" || req.body.yearoProfExp == "" || req.body.yearoProfAssiExp == "" || req.body.qRole == "") {
        res.json({ status: '0', msg: 'Please enter all required data.' });
        return;
    }
    var mName = "";
    if(req.body.lMname != "" && req.body.lMname != undefined){
        mName = req.body.lMname;
    }
    var session = res.locals.session;
    provider.qProviderRequestThird(session.id, req.body.lFname, mName, req.body.lLname, req.body.securityNum,
      req.body.dob, req.body.dlNum, req.body.dlstate, req.body.dlExpiration, req.body.hsInfo, req.body.clgInfo, req.body.yearoProfExp, req.body.yearoProfAssiExp,
      req.body.qRole, function (err, data) {
          if (err) {
              res.json({ status: '0', msg: 'error' });
              return;
          }
          else if (data.affectedRows > 0) {

              provider.qdetailsbyuserid(session.id, function(err,data) {
                  if(!err){
                      mail.sendQregistrationComplete(data[0].firstName + " " + data[0].lastName, data[0].roleOfQ, data[0].email, data[0].address, data[0].city, data[0].state, data[0].mobile, function (err, data) {
                        if (err) {
                            console.log(err);
                            res.json({ status: '0', msg: 'Error sending email ' });
                        }
                        else{
                          res.json({ status: '1', msg: 'Your Q provider account was created successfully.' });
                        }
                      });
                  }
                  else{
                    res.json({ status: '0', msg: 'Erro, User not found.' });
                  }
              });
              return;
          }
          else {
              res.json({ status: '0', msg: 'The user ID was not found.' });
              return;
          }
      });
});

//================================================== verify mobile num ===============================

router.post('/verifyMobile', function (req, res, next) {
    if (req.body.passcode == "" || req.body.passcode == undefined) {
        res.json({ status: '0', msg: 'Please enter the verification code' });
        return;
    }
    var session = res.locals.session;
    provider.verifyMobile(session.id, req.body.passcode, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'error' });
            return;
        }
        else if (data.affectedRows > 0) {
            res.json({ status: '1', msg: 'successfully verified' });
            return;
        }
        else {
            res.json({ status: '0', msg: 'You entered an incorrect verification code.  Please try again.' });
            return;
        }
    });
});

//=============================================== change mobile number ======================

router.put('/changeMobile', function (req, res, next) {
    random = Math.floor(100000 + Math.random() * 900000);
    var session = res.locals.session;
    if (req.body.newMobile == "" || req.body.newMobile == undefined) {
        res.json({ status: '0', msg: 'Please enter your new number.' });
        return;
    }
    else {
        provider.changeMobile(session.id, req.body.newMobile, random, function (err, data) {
            if (err) {
                res.json({ status: '0', msg: 'There was an error changing your number.' });
                return;
            }
            else if (data.affectedRows > 0) {
                mail.twilioSendMsg(req.body.mobile, "Your Q Now mobile phone verification code is " + random, function (err, data) {
                    if (err) {
                        console.log(err);
                    }
                    else {
                        console.log(data);
                    }
                });
                res.json({ status: '1', msg: 'A verification code was sent to your new mobile number.' });
                return;
            }
            else {
                res.json({ status: '0', msg: 'Incorrect token or ID.' });
                return;
            }
        });
    }
});

//======================================== resend otp to mobile number ===========================

router.get('/resendOtp', function (req, res, next) {
    try {
        random = Math.floor(100000 + Math.random() * 900000);
        var session = res.locals.session;
        provider.changeOtp(session.id, random, function (err, data) {
            if (err) {
                res.json({ status: '0', msg: 'There was an error resending your verification code.' });
                return;
            }
            else if (data[0][0].num == "") {
                res.json({ status: '0', msg: 'Unable to find your mobile number.' });
                return;
            }
            else {
                var mobile = data[0][0].num;
                mail.twilioSendMsg(mobile, "Your Q Now mobile phone verification code is " + random, function (err, data) {
                    if (err) {
                        console.log(err);
                    }
                    else {
                        console.log(data);
                    }
                });
                res.json({ status: '1', msg: 'The verification code was resent successfully' });
                return;
            }
        });
    } catch (err) {
        res.json({ status: '-1', msg: 'There was a server error.' });
    }
});

//=============================================qprovider activate=====================

router.put('/qProviderActive', function (req, res, next) {

    try {
        if (req.body.curLat == "" || req.body.curLong == "" || req.body.curLat == undefined || req.body.curLong == undefined) {
            res.json({ status: '0', msg: 'please provide Lat Long' });
            return;
        }
        var session = res.locals.session;


        provider.checkQBankAccount(session.id, function (err, data) {
            if (err) {
                res.json({ status: '0', msg: 'error' });
                return;
            }
            else {
                if (data.length > 0) {
                    provider.qProviderActive(session.id, req.body.curLat, req.body.curLong, function (err, data) {
                        if (err) {
                            res.json({ status: '0', msg: 'error' });
                            return;
                        }
                        else if (data.affectedRows > 0) {
                            res.json({ status: '1', msg: 'Successfully updated.' });
                            return;
                        }
                        else {
                            res.json({ status: '0', msg: 'Thank you for submitting your application.  We will be in touch.' });
                            return;
                        }
                    });
                }
                else {
                    res.json({ status: '0', msg: 'Please enter your Bank Account details in the Earnings Screen to begin accepting requests.' });
                    return;
                }
            }

        });
    } catch (err) {
        console.log(err);
    }

});

//================================  qprovider deactive =====================================

router.put('/qProviderDeactive', function (req, res, next) {
    var session = res.locals.session;
    provider.qProviderDeactive(session.id, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'error' });
            return;
        }
        else if (data[0].affectedRows > 0) {
            res.json({ status: '1', msg: 'You are offline.' });
            return;
        }
        else {
            res.json({ status: '0', msg: 'We encountered an error. Please try again.' });
            return;
        }
    });
})

//======================================= q provider average Rating =====================================

router.post('/qAverageRating', function (req, res, next) {
    if (req.body.qId == "" || req.body.qId == undefined) {
        res.json({ status: '0', msg: 'please enter qId' });
        return;
    }
    provider.qProviderAverageRating(req.body.qId, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'Unable to show your average rating at this time.' });
            return;
        }
        else if (data.length > 0) {
            for (var i = 0; i < data[1].length; i++) {
                console.log(data[1][i].ratingDate);
                var date = data[1][i].ratingDate + "";
                var train_date = date.split(" ");
                data[1][i].ratingDate = train_date[2] + " " + train_date[1] + " " + train_date[3];
            }
            res.json({ status: '1', averageRating: data[0][0].averageRating, Reviews: data[1] });
            return;
        }
        else {
            res.json({ status: '0', msg: 'No reviews have been submitted.' });
            return;
        }
    });
});

//==============================provider state================================================

router.get('/getStates', function (req, res, next) {
    provider.getstates(function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'error' });
            return;
        }
        else {
            res.json({ status: '1', state: data });
            return;
        }
    });
});

//==============================provider state================================================

router.post('/updateLocationOfQ', function (req, res, next) {
    if (req.body.qId == "" || req.body.curLat == "" || req.body.curLong == "") {
        res.json({ status: '0', msg: 'please provide data' });
        return;
    }
    provider.updateLocationOfQ(req.body.qId, req.body.curLat, req.body.curLong, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'error' });
            return;
        }
        else if (data.affectedRows > 0) {
            res.json({ status: '1', msg: 'Your location was updated successfully.' });
            return;
        }
        else {
            res.json({ status: '0', msg: 'Unable to update your location.  Please try again.' });
            return;
        }
    });
});

//==============================provider state================================================

router.get('/getSatusOfQ', function (req, res, next) {
    var session = res.locals.session;
    provider.getSatusOfQ(session.id, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'error' });
            return;
        }
        else {
            res.json({ status: '1', Qstatus: data[0] });
            return;
        }
    });
});

//====================== Create q bank account ===========================
router.post('/createQBankAccount', function (req, res, next) {
    if (req.body.accountHolderName == null || req.body.accountHolderName == "") {
        res.send(400, { error: "Please provide the account holder's name." });
        return;
    }
    if (req.body.accountHolderType == null || req.body.accountHolderType == "") {
        res.send(400, { error: "Please select the account type." });
        return;
    }
    if (req.body.routingNumber == null || req.body.routingNumber == "") {
        res.send(400, { error: "Please provide your routing number." });
        return;
    }
    if (req.body.accountNumber == null || req.body.accountNumber == "") {
        res.send(400, { error: "Please provide your account number." });
        return;
    }
    var tokenDetails = {
        bank_account: {
            country: "US",
            currency: "usd",
            account_holder_name: req.body.accountHolderName,//optional
            account_holder_type: req.body.accountHolderType,//optional
            routing_number: req.body.routingNumber,//optional
            account_number: req.body.accountNumber
        }
    };

    var session = res.locals.session;
    stripeModel.createQStripeBankAccount(session.id, tokenDetails, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: err.message });
            return;
        }
        else {
            res.json({ status: '1', msg: "Your bank account information was securely entered successfully." });



            // return;
        }
    });



});


//=============================================qprovider verified=====================

router.get('/isQProviderVerified', function (req, res, next) {
    var session = res.locals.session;
    provider.isQProviderVerified(session.id, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'error' });
            return;
        }
        else if (data[0].isQVerified != undefined && data[0].isQVerified == 1) {
            res.json({ status: '1', msg: 'Your Q provider account has been verified.' });
            return;
        }
        else {
            res.json({ status: '0', msg: 'Thank your for submitting your application. We will be in touch.' });
            return;
        }
    });
});



//==============================Provider Route Map ================================================

router.post('/routeMapOfQ', function (req, res, next) {
    if (req.body.qRequestId == "" || req.body.curLat == "" || req.body.curLong == "") {
        res.json({ status: '0', msg: 'please provide data' });
        return;
    }
    provider.routeMapOfQ(req.body.qRequestId, req.body.curLat, req.body.curLong, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'error' });
            return;
        }
        else if (data.affectedRows > 0) {
            res.json({ status: '1', msg: 'This Location is updated Succesfully' });
            return;
        }
        else {
            res.json({ status: '0', msg: 'Unable to update your current location.  Please try again.' });
            return;
        }
    });
});


module.exports = router;
