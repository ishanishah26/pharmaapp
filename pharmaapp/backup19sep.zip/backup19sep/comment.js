//var apn = require('apn');
// //======================================== push notification ============================
//
// router.post('/notifyAndroid', function (req, res, next) {
//
//  var token="fq6kBfziFjk:APA91bGEnbQAuLQARxm3uOj94R88e-cxr23niiks0nNjDfiTPv12FzjsxJHY_OQnYmKQhKZ-qUNZzVzntmObc5qLcMHVKad6JRTs_JrRul7LQ8yWpU1ab1zn5XNdi5q8ICdYqDxh4lzk";
//
// user.sendAndroidNotification(req.body.message, token, function (err, data) {
//       if (err) {
//           return next(err);
//       }
//       else {
//           res.send(200, data);
//           return;
//       }
//   })
// });


// //============================================= pushnotification in apple ======================================
//
// router.get('/notifyApple',function(req,res,next){
//            apn.pushNotification(function(err,data){
//                  if(err)
//                  {
//                    res.json({status:'0', msg:'error in submiting rating'});
//                  }
//                  else
//                  {
//                     res.json({status:'0', msg:'no qProvider is online'});
//                  }
//            });
// });


// //================================================== rating ==============================
//
//  exports.rate=function(userId,sppedRating,qualityRating,feedback,callback) {
//      connect.query('insert into qRequest(speedRating,qualityRating,feedback) values("'+ sppedRating +'","'+ qualityRating +'","'+ feedback +'")',function(err,data) {
//          if(!err)
//          {
//              callback(null,data);
//          }
//          else
// 				 {
//              callback(err,null);
//          }
//      });
//  }

//======================================push notification-====================
//  var schedule = require('node-schedule');
// //
// var j = schedule.scheduleJob('*/5 * * * *', function(){
// 							var message = new gcm.Message({
// 								timeToLive: 20,
// 								"data":{
// 										"key1": "Any Thing Else"
// 								},
// 								"notification": {
// 										"Title": "New Request",
// 										"Verb": "arrange",
// 										"Noun": "party"
// 									}
// 								});
// 							var deviceToken = "fXLe34oYkns:APA91bEyd1SwVHkV2QNhWMELrfxJ3ghtg0hSEw1bJEJi5TZiTmoqz5rBw2vz83F2PYeQJQ2Q8vRD_ox3DWF6mMZD2ViUCCWrLT7Aousat1ozmWiTVm0VLeHnJyMaq8CixZzKuAnrtN8P";
// 						gcmSender.send(message, { registrationTokens: [deviceToken] }, function (err, response) {
// 									if (err) {
// 										 console.error(err);
// 									}
// 									else
// 									{
// 										 console.log(response);
// 									}
// 						});
// });

	// exports.sendAndroidNotification = function (notificationData, deviceToken, callback) {
	//          var message = new gcm.Message(notificationData);
	//
	//   gcmSender.send(message, { registrationTokens: [deviceToken] }, function (err, response) {
	//       if (err) {
	//           console.error(err);
	//           callback(err, false);
	//       }
	//       else {
	//           callback(null, response);
	//       }
	//   });
	// }

	// //========================================= static push notificatio ================================================
	//
	//  var schedule = require('node-schedule');
	// var j = schedule.scheduleJob('*/5 * * * *', function(){
	// 							var message = new gcm.Message({
	// 								timeToLive: 20,
	// 								"data":{
	// 										"key1": "Any Thing Else"
	// 								},
	// 								"notification": {
	// 										"Title": "New Request",
	// 										"Verb": "arrange",
	// 										"Noun": "party",
	//                     "cost": "$10-$20",
	//                     "time": "3 hrs",
	//                     "requestId": "12980487-f6fb-11e5-8055-386077c711ee"
	// 									}
	// 								});
	// 							var deviceToken = "dpDMXtM4Avc:APA91bHv8tBapoLr5jdnStGgq1ud5Brpqul9Xp8-CnjlxU9hJ8y9NrxmqxjRnoFATXB02slsTQrsUSx4rfnPwgXkyBnD19GBEZChDU08KeBRI0EnhBsO-f06vgvNweBaKmREUA-hKjS3";
	// 						gcmSender.send(message, { registrationTokens: [deviceToken] }, function (err, response) {
	// 									if (err) {
	// 										 console.error(err);
	// 									}
	// 									else
	// 									{
	// 										 console.log(response);
	// 									}
	// 						});
	// });

	//
	// //===================================== new register ==============================
	//
	//   exports.registerNew  = function(fname,lname,email,mobile,password,random,deviceToken,deviceType,callback) {
	// 		var image = "public/static_image/user-icon.png"
	// 							connect.query('CALL user_register("'+ email +'","'+ mobile +'","'+ password +'","'+ random +'","'+ fname +'","'+ lname +'","'+ image +'","'+ deviceToken +'","'+ deviceType +'")',function(err, data){
	// 		                  if(!err)
	// 		                  {
	// 												callback(null, data);
	// 		                  }
	// 		                  else
	// 		                  {
	// 		                    callback(err,null);
	// 		                  }
	// 		          });
	//   }
	//
	// // ============================================ Signin ==================================
	//
	// 	exports.signin  = function(email,password,deviceToken,deviceType,callback) {
	//
	// 					connect.query('SELECT user.userId, user.firstName, user.lastName, user.email, user.mobile, user.isEmailVerified, user.userProfile , qProvider.qId, qProvider.registrationStepCompleted FROM user LEFT JOIN qProvider ON qProvider.userId = user.userId WHERE user.email = "'+ email +'" AND password="'+ password +'"',function(err, data){
	// 									if(!err)
	// 									{
	// 													if(data.length > 0)
	// 													{
	// 																	var id = data[0].userId;
	// 																	connect.query('UPDATE user SET deviceToken = "'+ deviceToken +'", deviceType = "'+ deviceType +'" WHERE userId = "'+ id +'"',function(err, data){
	// 																						if(err)
	// 																						{
	// 																									callback(err, null);
	// 																						}
	// 																	});
	// 																	callback(null, data);
	// 													}
	// 									}
	// 									else
	// 									{
	// 										callback(err,null);
	// 									}
	// 					});
	// 	}
//forgot password

// transporter.sendMail({
//       host : "localhost",
//       port : "25",
//       domain : "localhost",
//       to : req.body.email,
//       //to : "lanetteam.krutika@gmail.com",
//       from : "lanetteam.jinal@gmail.com",
//       subject : "node_mailer test email",
//       html:"<h1>Qapp</h1><br><h3>Hii, From here you can reset your password</h3>" + "<a href='http://192.168.200.68:8000/forgotPassword/?random="+ random +"'>click here</a>"+ "<h3>Thank you</h3>"
//     },
//     function(err, data){
//       if(err)
//       {
//             res.json({status:'0',msg:'mail is not send'});
//             return;
//       }
//       else
//       {
//             res.json({status:'1',msg:'link is send to your email'});
//             return;
//       }
//     });

//  if(data.lenght < 0){
//    res.json({status:'0',msg:'no request found'});
//  }
//================================================================= in tblrequest.js =================================

// 	var message = new apn.notification();
// 	message.expiry = Math.floor(Date.now() / 1000) + 3600; // Expires 1 hour from now.
// 	message.badge = 3;
// 	message.sound = "ping.aiff";
// 	message.setAlertText({ "title" : "New Request"});
// 	message.payload = {
// 	"notification": {
// 					"key": "1",
// 					"Title": "New Request",
// 					"Verb": ""+ verb,
// 					"Noun": ""+ noun,
// 					"cost": ""+ price ,
// 					"time": ""+ time,
// 					"Lat": ""+ curLat,
// 					"Long": ""+ curLong,
// 					"requestId": ""+ data[3][0]['@QrequestId']
// 		}};
//
// var options = { "gateway": "gateway.sandbox.push.apple.com", "cert": __dirname + "/Certificatesdev.pem", "key": __dirname + "/CertificatesdevKey.pem", "passphrase:": "QApp" };
// var service = new apn.connection(options);
// service.on('transmitted', function(notification, device) {
//     console.log("Notification transmitted to:" + device.token.toString('hex'));
// });
//
// service.on('transmissionError', function(errCode, notification, device) {
//     console.error("Notification caused error: " + errCode + " for device ", device, notification);
// });
// //var deviceId = "9cd4dfb62ffe86fa5da9662904478b6886da1b7770a3c1fe6ea194a965d15392";
// var device = new apn.Device(deviceTokenI);
// service.pushNotification(message, device);
//============================================================= tblrequest.ja ============================
// for request accept
var message = new apn.notification();
	message.expiry = Math.floor(Date.now() / 1000) + 3600; // Expires 1 hour from now.
	message.badge = 3;
	message.sound = "ping.aiff";
	message.setAlertText({ "title" : "New Request"});
	message.payload = {
	"notification": {
					"key": "2",
					"Title": "Request Accepted",
					"Verb": ""+ data[1][0].requestVerb,
					"Noun": ""+ data[1][0].requestNoun,
					"requestId": ""+ requsetId,
					"Message": "Your request accepted"
		}};

var options = { "gateway": "gateway.sandbox.push.apple.com", "cert": __dirname + "/Certificatesdev.pem", "key": __dirname + "/CertificatesdevKey.pem", "passphrase:": "QApp" };
var service = new apn.connection(options);
service.on('transmitted', function(notification, device) {
		console.log("Notification transmitted to:" + device.token.toString('hex'));
});

service.on('transmissionError', function(errCode, notification, device) {
		console.error("Notification caused error: " + errCode + " for device ", device, notification);
});
var deviceId = "9cd4dfb62ffe86fa5da9662904478b6886da1b7770a3c1fe6ea194a965d15392";
var device = new apn.Device(deviceId);
service.pushNotification(message, device);
//============================================================ request.js ================================
// data format
var date = req.body.requiredDate;
var requiredDate = str.replace("/", "-");
// var train_date = date.split("-");
// var requiredDate = train_date[2] +"-"+train_date[1]+"-"+train_date[0];
// confirmed completed
UPDATE qRequestAccept '
+'SET isConfirmedByQ = 1  WHERE qRequestId="'+ qRequestId +'"; UPDATE qRequest SET requestStatus = "3" WHERE qRequestId="'+ qRequestId +'";


//============================================== cancel request ===================================================

router.post('/totalCompletedStop',function(req,res,next){
  if(req.body.qRequestId == "" || req.body.qRequestId == undefined )
     {
           res.json({status: '0', msg : 'please provide qRequestId'});
      return;
     }
  request.totalCompletedStop(req.body.qRequestId,function(err,data){
            if(err)
            {
                  res.json({status:'0',msg:'error in change status'});
                  return;
            }
            else if(data.length > 0)
            {
                  res.json({status:'1', stop: data});
                  return;
            }
      });
});
//===================================== connection ===============================
	//
	// connect.connect(function(err){
	// if(!err)
	// console.log("done connection");
	// else
	// console.log("error in connection");
	// });

	// var dbconfig = {
	// 	host: '192.168.200.81',
	// 	user: 'test',
	// 	password: 'test',
	// 	database: 'finalQapp',
	// 	multipleStatements: true
	// }
	// var mysql = require('mysql');
	// var connection;
	//
	// function handleDisconnect() {
	//   connection = mysql.createConnection(dbconfig); // Recreate the connection, since
	//                                                   // the old one cannot be reused.
	//
	//   connection.connect(function(err) {              // The server is either down
	//     if(err) {                                     // or restarting (takes a while sometimes).
	// 		      console.log('error when connecting to db:', err);
	// 		      setTimeout(handleDisconnect, 2000); // We introduce a delay before attempting to reconnect,
	//     }
	// 		else
	// 		{
	// 					console.log("done Connection");
	// 		}                                    // to avoid a hot loop, and to allow our node script to
	//   });                                     // process asynchronous requests in the meantime.
	//                                           // If you're also serving http, display a 503 error.
	//   connection.on('error', function(err) {
	//     console.log('db error', err);
	//     if(err.code === 'PROTOCOL_CONNECTION_LOST') { // Connection to the MySQL server is usually
	//       handleDisconnect();                         // lost due to either server restart, or a
	//     } else {                                      // connnection idle timeout (the wait_timeout
	//       throw err;                                  // server variable configures this)
	//     }
	//   });
	// }
	//
	// handleDisconnect();
//===============================================================================================================
twilio:
API Credentials
To use the Twilio API you will need your AccountSid and Auth Token.

ACCOUNT SID

ACac1adfd7285efc0563531146a9bf379f

AUTH TOKEN

39d3aadc66471306e5aac6f5d7e4ac95
Phone #: +1 310-789-2160
Login: Felix@myqapp.com pswd: Developer1234
Email Username:
receipts@myqapp.com
SMTP Server:
myqappcom.domain.com ( port 587 )
POP Server:
myqappcom.domain.com ( port 110 )
