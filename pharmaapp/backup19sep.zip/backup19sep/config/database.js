exports.dbconfig = {
	host: 'localhost',
	user: 'root',
	password: 'root',
	database: 'Qnow',
	multipleStatements: true
}
// exports.dbconfig = {
// 	host: 'localhost',
// 	user: 'root',
// 	password: 'wR0C8i885TzpU9TEb0R76',
// 	database: 'Qnow',
// 	multipleStatements: true
// }
//encryption key
exports.key = 'Qappkimberlyrealsecretkeyrandom';
exports.webPort = 80;
exports.path = "http://198.61.223.30/images/";
exports.JWTPrivateKey = "1234";
exports.expiresIn = 86400;  //in seconds
exports.TwilioAccountId = "ACac1adfd7285efc0563531146a9bf379f";
exports.TwilioAuthToken = "39d3aadc66471306e5aac6f5d7e4ac95";
exports.TwilioNumber = "+13107892160";

 exports.gcmSenderKey = "AIzaSyC_39FmoE40BQp2BrXvMEhD-9jPj0C_j7Q";
// exports.stripeTestSecretKey = "sk_live_GMGH2Q2I6nPuGsHLeHuIHp3k";
// exports.stripeTestPublishKey = "pk_live_Ov7RYkw3qmuOGHSLr9Uz5asf";




//exports.stripeTestSecretKey = "sk_test_W3RDD23NiW1ewcGuqBOV5YNU";
//exports.stripeTestPublishKey = "pk_test_3n5iRg9ZKnjJWXBttso6hUdA";

//stripe key new
exports.stripeTestSecretKey = "sk_test_eow6crkdhNW9iEiUKY95pwSl";
exports.stripeTestPublishKey = "pk_test_QgYWkdqXpTLF6Xxb7fdS7Xt8";
//exports.gcmSenderKey = "AIzaSyCy_tBoJyfxSNYr7zbqMTgls6VuemHAjpI";


//============================twillio======================
//=====================live account=============
exports.accountSid="ACac1adfd7285efc0563531146a9bf379f";
exports.authToken="39d3aadc66471306e5aac6f5d7e4ac95";
// exports.phoneNumber="+13107892160";
// exports.applicationSid="AP8eeca0f265b44ff2f27412396eb18be5";

//=============test account credentials============
/*exports.accountSid="AC76fa275a1de4b9f87a46b2eed7e4840b";
exports.authToken="fc4b03e0bd1b84afd9803b3a95956edd";
exports.phoneNumber="+13107892160";
exports.applicationSid="AP8eeca0f265b44ff2f27412396eb18be5";*/




exports.smtpConfigReceipts = {
   host: 'myqapp.domain.com',
   port: 587,
   auth: {
       user: 'receipts@theqnowapp.com',
       pass: 'Qapp@1234'
   },
	 tls: {
		rejectUnauthorized: false
	}
};

exports.smtpConfigVerification = {
   host: 'myqapp.domain.com',
   port: 587,
   auth: {
       user: 'info@theqnowapp.com',
       pass: 'Qapp@1234'
   },
	 tls: {
		rejectUnauthorized: false
	}
};


exports.apnConfig = {
   "gateway": "gateway.sandbox.push.apple.com",
 	"cert": __dirname + "/model/Certificates_dis.pem",
	"key":  __dirname + "/model/Certificates_dis_Key.pem",
        "passphrase": "QApp"
};

exports.transportBaseRate = 18;//base rate transport 18
exports.transportDistanceRate = 0.20;//distanse rate for transport = .20
exports.transportDurationRate = 0.30;//Transport duration rate = .30

exports.anythingelseBaseRate = 22;//base rate anything else 22
exports.anythingelseDurationRate = 0.36;//anything else duration rate .36

exports.serviceFeeToQ = 0.20;//Service fee  to q  = 20% of request amt
exports.serviceFeeToUser = 0.05;//Service fee  to user  = 5% of the request amt

exports.servicePrechargeAmount = 1;//User pre charged for the request
exports.servicePaneltyCharge = 5; //User is charged panelty for canceling request
exports.mapUrl = "https://maps.googleapis.com/maps/api/staticmap?zoom=13&size=400x400&markers=color:red{{0}}&markers=color:red{{1}}&key=AIzaSyC1dekbMOABfjju-AaqhtK8xQZa3CbUw9k";


//POP Server: myqappcom.domain.com ( port 110 )
